#include<algorithm>
#include "../../../Utility/Utility3D.h"
#include "../../../Utility/UtilityCommon.h"
#include "../../../Utility/Utility2D.h"
#include "../../../Manager/Resource/ResourceManager.h"
#include "../../../Manager/Generic/SceneManager.h"
#include "../../../Manager/Generic/Camera.h"
#include "../../../Manager/Generic/DataBank.h"
#include "../../../Manager/Generic/UIManager.h"
#include "../Manager/Game/CharacterManager.h"
#include"../../Common/Geometry/Capsule.h"
#include"../../Common/Geometry/Sphere.h"
#include"../../Common/Geometry/Line.h"
#include"../Object/Card/CardDeck.h"
#include "../../Card/CardPresenter.h"
#include"../Object/Card/PlayerCardUI.h"
#include "../../../Object/Common/AnimationController.h"
#include"./ActionController.h"
#include"../Base/CharacterOnHitBase.h"
#include"./PlayerOnHit.h"
#include "./Weapon.h"
#include"../Base/ActionBase.h"
#include"../Action/Idle.h"
#include"../Action/Run.h"
#include"../Action/React.h"
#include"../Action/Dodge.h"
#include"../Action/PlayerCardAction.h"
#include "./PlayerLogic.h"
#include "Player.h"

Player::Player(void)
	:playerNum_(),
	cntl_(InputManager::CONTROLL_TYPE::ALL),
	padNum_(),
	stateUpdate_()
{
	padNum_ = static_cast<InputManager::JOYPAD_NO>(playerNum_ + 1);//���߂�JOYPAD��key_pad�Ȃ̂Ńp�b�h�̔ԍ��ɍ��킹��
	characterType_ = CHARACTER_TYPE::PLAYER;
	footSEDisCount_ = FOOT_SE_DIS;
	footSE_ = ResourceManager::SRC::PLAYER_FOOT_SE;
	capRadius_ = CAP_RADIUS;
	deck_ = std::make_shared<CardDeck>(characterType_, PLAYER_NUM);
	cardPresent_ = std::make_unique<CardPresenter>(characterType_, *deck_);
	weapon_ = std::make_unique<Weapon>(*this);
	logic_ = std::make_unique<PlayerLogic>(trans_, isMoveable_, padNum_, InputManager::CONTROLL_TYPE::ALL);
	hipBoneNo_ = SPINE_FRAME_NO;

	

}

Player::~Player(void)
{
	collider_.clear();
}

void Player::Load(void)
{
	trans_.SetModel(resMng_.LoadModelDuplicate(ResourceManager::SRC::PLAYER));
	trans_.scl = MODEL_SCL;
	trans_.quaRotLocal =
		Quaternion::Euler({ 0.0f, UtilityCommon::Deg2RadF(MODEL_LOCAL_DEG), 0.0f });
	trans_.pos = { 0.0f,0.0f,-CENTER_POS_Z_OFFSET };
	trans_.localPos = { 0.0f,Player::CAP_RADIUS,0.0f };

	//�X�e�[�^�X�̃��[�h
	LoadStatus();

	//�A�j���[�V�����̒ǉ�
	LoadAddAnimation();

	//�A�N�V�����̒ǉ�
	AddAction();
	
	action_->Load();
	weapon_->Load();

	resMng_.Load(SoundManager::SRC::ENEMY_HIT_SE);
}

void Player::Init(void)
{

	//����̒Ǐ]�Ώۂ��Z�b�g
	weapon_->SetTargetAndFrameNo(&trans_, HAND_FRAME_NO);

	tag_ = Collider::TAG::PLAYER1;
	
	//�v���C���[����
	logic_->Init();

	MakeColliderGeometry();

	action_->Init();
	weapon_->Init();

	deck_->Init();

	//�X�V
	trans_.Update();
}

void Player::UpdateDirection(void)
{
	//Transform�̍X�V
	trans_.quaRot = charaRot_.playerRotY_;
	trans_.Update();

	//�A�j���[�V�����̍X�V
	animationController_->Update();

	//����̍X�V
	weapon_->Update();


}

void Player::UpdateNormal(void)
{
	//�v���C���[��ԍX�V
	Action();

	//�A�j���[�V����
	animationController_->Update();

	//����
	weapon_->Update();
}

void Player::UpdateClearDirection(void)
{
	//���o�Ɠ����X�V
	UpdateDirection();

	//�v���C���[��ԍX�V
	Action();
}

void Player::UpdateOverDirection(void)
{
	UpdateDirection();
	if (animationController_->IsEnd(static_cast<int>(ANIM_TYPE::DEATH)))
	{
		isEndClearDirect_ = true;
	}
}

void Player::ChangeUpdateOverDirection(void)
{
	animationController_->Play(static_cast<int>(ANIM_TYPE::DEATH),false);
	CharacterBase::ChangeUpdateOverDirection();
}

void Player::Draw(void)
{
	//�ʏ�`��
	MV1DrawModel(trans_.modelId);

	weapon_->Draw();
}

void Player::Draw2D(void)
{

#ifdef _DEBUG
	//action_->DrawDebug();
	DrawDebug();
#endif // _DEBUG
}
void Player::OnHit(const std::weak_ptr<Collider> _hitCol)
{
	onHit_->OnHitUpdate(_hitCol);
}

void Player::MoveDirFromInput(void)
{
	//�v���C���[���̓N���X����p�x���擾
	charaRot_.dir_ = logic_->GetDir();
	charaRot_.dir_ = VNorm(charaRot_.dir_);
}

void Player::SetGoalRotate(void)
{
	//�x�N�g������N�H�[�^�j�I����
	Quaternion axis = Quaternion::LookRotation(logic_->GetDir());

	//���ݐݒ肳��Ă����]�Ƃ̊p�x�������
	double angleDiff = Quaternion::Angle(axis, charaRot_.goalQuaRot_);

	constexpr double ANGLE_THRESHOLD = 0.1;
	// �������l
	if (angleDiff > ANGLE_THRESHOLD)
	{
		charaRot_.stepRotTime_ = TIME_ROT;
	}

	charaRot_.goalQuaRot_ = axis;
}

void Player::MakeAttackCol(const Collider::TAG _charaTag, const Collider::TAG _attackTag, const VECTOR& _atkPos, const float& _radius)
{
	//���łɓ����蔻�肪����ꍇ�͍��Ȃ�
	if (weapon_->IsAliveCollider(_charaTag, _attackTag))return;
	weapon_->MakeWeaponCollider();
}

void Player::DeleteAttackCol(const Collider::TAG& _charaTag, const Collider::TAG& _attackCol)
{
	if (!weapon_->IsAliveCollider(_charaTag, _attackCol))return;
	weapon_->DeleteWeaponCollider();
}

void Player::Damage(const int _dam)
{
	CharacterBase::Damage(_dam);
}

#ifdef _DEBUG
void Player::DrawDebug(void)
{
	//for (auto& col : collider_)
	//{
	//	col.second->GetGeometry().Draw();
	//}

	animationController_->DrawDebug();
}

#endif // _DEBUG

void Player::AddAnimation(void)
{
	//animationController_ = std::make_unique<AnimationController>(trans_.modelId, SPINE_FRAME_NO);
	//animationController_->Add(static_cast<int>(ANIM_TYPE::IDLE), DEFAULT_ANIM_SPEED, resMng_.LoadModelDuplicate(ResourceManager::SRC::P_IDLE));
	//animationController_->Add(static_cast<int>(ANIM_TYPE::RUN), DEFAULT_ANIM_SPEED, resMng_.LoadModelDuplicate(ResourceManager::SRC::P_RUN));
	//animationController_->Add(static_cast<int>(ANIM_TYPE::REACT), DEFAULT_ANIM_SPEED, resMng_.LoadModelDuplicate(ResourceManager::SRC::REACT));
	//animationController_->Add(static_cast<int>(ANIM_TYPE::DODGE), DODGE_ANIM_SPD, resMng_.LoadModelDuplicate(ResourceManager::SRC::P_DODGE));
	//animationController_->Add(static_cast<int>(ANIM_TYPE::DEATH), DEFAULT_ANIM_SPEED, resMng_.LoadModelDuplicate(ResourceManager::SRC::P_DEATH));
	//animationController_->Add(static_cast<int>(ANIM_TYPE::CARD_RELOAD), DODGE_ANIM_SPD, resMng_.LoadModelDuplicate(ResourceManager::SRC::P_RELOAD));
	//animationController_->Add(static_cast<int>(ANIM_TYPE::ATTACK_1_MIDDLE), ATK_MID_ANIM_SPD, resMng_.LoadModelDuplicate(ResourceManager::SRC::P_ATTACK_1_MIDDLE));
	//animationController_->Add(static_cast<int>(ANIM_TYPE::ATTACK_1_SHORT), DEFAULT_ANIM_SPEED, resMng_.LoadModelDuplicate(ResourceManager::SRC::P_ATTACK_1_SHORT));
	//animationController_->Add(static_cast<int>(ANIM_TYPE::ATTACK_2), DEFAULT_ANIM_SPEED, resMng_.LoadModelDuplicate(ResourceManager::SRC::P_ATTACK_2));
	//animationController_->Add(static_cast<int>(ANIM_TYPE::ATTACK_3), DEFAULT_ANIM_SPEED, resMng_.LoadModelDuplicate(ResourceManager::SRC::P_ATTACK_3));
}

void Player::AddAction(void)
{
	//�A�N�V����
	action_ = std::make_unique<ActionController>(*this, *logic_, trans_, *cardPresent_, *animationController_, padNum_);
	using ACTION_TYPE = ActionController::ACTION_TYPE;
	action_->AddAction({ ACTION_TYPE::IDLE, ACTION_TYPE::MOVE,ACTION_TYPE::REACT,  ACTION_TYPE::CARD_ACTION,ACTION_TYPE::DODGE });
}

void Player::MakeColliderGeometry(void)
{
	//�J�v�Z��
	std::unique_ptr<Geometry>geo = std::make_unique<Capsule>(trans_.pos, trans_.quaRot, CAP_LOCAL_TOP, CAP_LOCAL_DOWN, CAP_RADIUS);
	MakeCollider(TAG_PRIORITY::BODY, { tag_ }, std::move(geo));
	tagPrioritys_.emplace_back(TAG_PRIORITY::BODY);

	//���݂̍��W�ƈړ�����W�����񂾐��̃R���C�_(�������̓����蔻��)
	geo = std::make_unique<Line>(trans_.pos, trans_.quaRot, Utility3D::VECTOR_ZERO, Utility3D::VECTOR_ZERO);
	MakeCollider(TAG_PRIORITY::MOVE_LINE, { tag_ }, std::move(geo));
	tagPrioritys_.emplace_back(TAG_PRIORITY::MOVE_LINE);

	//�㉺���C��
	geo = std::make_unique<Line>(trans_.pos, trans_.quaRot, CAP_LOCAL_TOP, CAP_LOCAL_DOWN);
	MakeCollider(TAG_PRIORITY::UPDOWN_LINE, { tag_ }, std::move(geo));
	tagPrioritys_.emplace_back(TAG_PRIORITY::UPDOWN_LINE);

	onHit_ = std::make_unique<PlayerOnHit>(*this, movedPos_, moveDiff_, *action_, collider_, trans_);
	onHit_->Init();
	onHit_->Load();
}

void Player::Action(void)
{
	//���W�b�N
	logic_->Update();

	//�A�N�V�����֌W�̍X�V
	action_->Update();

	//�����蔻��̍X�V
	UpdatePost();

	trans_.quaRot = charaRot_.playerRotY_;
	trans_.Update();
}

