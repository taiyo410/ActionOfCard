#include "../Manager/Generic/SceneManager.h"
#include "../Manager/Resource/SoundManager.h"
#include "../Base/ActionBase.h"
#include"../Base/LogicBase.h"
#include"../Utility/Utility3D.h"
#include"../Player/ActionController.h"
#include"../Base/CharacterBase.h"
#include"../../Common/AnimationController.h"
#include "Run.h"

Run::Run(ActionController& _actCntl, CharacterBase& _character, const float _speed, ResourceManager::SRC _src, const float  _footSeDis):
	ActionBase(_actCntl,_character),
	moveSpd_(_speed),
	footSESrc_(_src),
	footSeDis_(_footSeDis),
	footSECnt_()
{
	speed_ = moveSpd_;
}

Run::~Run(void)
{
}

void Run::Load(void)
{
	resMng_.Load(footSESrc_);
}

void Run::Init(void)
{
	//anim_.Play(static_cast<int>(CharacterBase::ANIM_TYPE::RUN));
	//anim_.PlayBlend(static_cast<int>(CharacterBase::ANIM_TYPE::RUN),BLEND_TIME);
	character_.PlayCharacterAnim(CharacterBase::ANIM_TYPE::RUN);
	footSECnt_ = 0.0f;
}

void Run::Update(void)
{
	//���͕�����0�������ꍇ�A�A�C�h����Ԉڍs
	if (!actionCntl_.GetInput().GetIsAct().isRun)
	{
		actionCntl_.ChangeAction(ActionController::ACTION_TYPE::IDLE);
		return;
	}

	//�J�[�h����ɏo������
	if (actionCntl_.IsCardDecisionControl() && actionCntl_.GetInput().GetIsAct().isCardUse)
	{
		actionCntl_.ChangeAction(ActionController::ACTION_TYPE::CARD_ACTION);
		return;
	}

	//�W�����v���͂��������ꍇ�A�W�����v��Ԃֈڍs
	if (actionCntl_.GetInput().GetIsAct().isJump)
	{
		actionCntl_.ChangeAction(ActionController::ACTION_TYPE::JUMP);
		return;
	}

	//�����Ԉڍs
	if (actionCntl_.GetInput().GetIsAct().isDodge)
	{
		actionCntl_.ChangeAction(ActionController::ACTION_TYPE::DODGE);
		return;
	}

	if (footSECnt_ <= 0.0f)
	{
		SoundManager::GetInstance().Play(footSESrc_, SoundManager::PLAYTYPE::BACK);
		footSECnt_ = footSeDis_;
	}
	else
	{
		footSECnt_ -= scnMng_.GetDeltaTime();
	}
}
