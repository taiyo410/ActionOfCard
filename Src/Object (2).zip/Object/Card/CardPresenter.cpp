#include "../pch.h"
#include "../Card/CardUiBase.h"
#include "../Card/CardDeck.h"
#include "../../Manager/Generic/UIManager.h"
#include "CardPresenter.h"

CardPresenter::CardPresenter(CHARACTER_TYPE& _type, CardDeck& _deck):
	deck_(_deck),
	type_(_type),
	uiMng_(UIManager::GetInstance())
{
}

CardPresenter::~CardPresenter(void)
{
}

void CardPresenter::FinishCard(void)
{
	//�g�p�ς݂ֈڍs
	uiMng_.GetCardUI(type_).ChangeUsedActionCard();
	deck_.EraseHandCard();
	uiMng_.GetCardUI(type_).ChangeSelectState(CardUIBase::CARD_SELECT::NONE);
}

void CardPresenter::FailureCard(void)
{
	//�e����Ԃֈڍs
	uiMng_.GetCardUI(type_).ChangeReactActionCard();
	deck_.EraseHandCard();
}

void CardPresenter::PutCard(void)
{
	//��D����h���[���Ɉړ�
	deck_.MoveUsingCardToDrawPile();

	//�����ԂɈڍs
	uiMng_.GetCardUI(type_).ChangeSelectState(CardUIBase::CARD_SELECT::DISITION);
}


void CardPresenter::RoleRevolver(const CardUIBase::CARD_SELECT _moveLR)
{
	//���E�ȊO�̂Ƃ��͏������Ȃ�
	if (_moveLR != CardUIBase::CARD_SELECT::LEFT && _moveLR != CardUIBase::CARD_SELECT::RIGHT)return;

	//UI�̃J�[�h���{���o�[��]
	uiMng_.GetCardUI(type_).ChangeSelectState(_moveLR);

	//�����̃J�[�h�𓮂���
	_moveLR == CardUIBase::CARD_SELECT::LEFT ? deck_.CardMoveLeft() : deck_.CardMoveRight();
}

const CardBase::CARD_TYPE CardPresenter::GetCardType(void) const
{
	return deck_.GetDrawCardType();
}

const std::vector<CardBase::CARD_TYPE> CardPresenter::GetHandCardType(void) const
{
	return deck_.GetHandCardType();
}

void CardPresenter::DeckReload(void)
{
	deck_.Reload();
	uiMng_.GetCardUI(type_).ChangeSelectState(CardUIBase::CARD_SELECT::RELOAD);
}

void CardPresenter::ChangeCard(void)
{
	//���ݎg���Ă���J�[�h���̂Ă�
	deck_.EraseHandCard();

	//��D�Ɉړ�
	deck_.MoveUsingCardToDrawPile();

	//UI���g�p�ςݏ�Ԃֈڍs
	uiMng_.GetCardUI(type_).ChangeUsedActionCard();

	//�����Ԃֈڍs
	uiMng_.GetCardUI(type_).ChangeSelectState(CardUIBase::CARD_SELECT::DISITION);
}

void CardPresenter::EnemyCardReload(void)
{
	//�����I�ȃ����[�h
	deck_.Reload();

	//UI�������[�h��ԂɑJ��
	uiMng_.GetCardUI(type_).ChangeSelectState(CardUIBase::CARD_SELECT::RELOAD_WAIT);
}

void CardPresenter::ChangeAction(void)
{
	//�g�p�ς݂ֈڍs
	uiMng_.GetCardUI(type_).ChangeUsedActionCard();

	//�A�N�V�������J�[�h������
	deck_.EraseHandCard();
}

const bool CardPresenter::IsCardFailure(void)const
{
	return deck_.IsCardFailure();
}

void CardPresenter::SetUIReloadCount(const float _per)
{
	uiMng_.GetCardUI(type_).SetReloadCount(_per);
}

void CardPresenter::ChangeUIState(const CardUIBase::CARD_SELECT _select)
{
	uiMng_.GetCardUI(type_).ChangeSelectState(_select);
}

const CardUIBase::CARD_SELECT CardPresenter::GetCardUIState(void) const
{
	return uiMng_.GetCardUI(type_).GetSelectState();
}
