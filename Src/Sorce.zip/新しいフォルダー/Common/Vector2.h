#pragma once
#include "./Vector2F.h"

struct Vector2
{
	int x;
	int y;

	/// @brief ���K��
	/// @param  
	/// @return 
	Vector2 Normalize(void) const;

	/// @brief ���������߂�
	/// @param  
	/// @return 
	float Length(void) const;

	/// @brief Vector2���m�̔�r
	/// @param value1 �x�N�g��1
	/// @param value2 �x�N�g��2
	/// @return 
	static bool IsVector2(const Vector2 value1, const Vector2 value2);
	
	/// @brief Vector2���m�̒l������������r
	/// @param value1 �x�N�g��1
	/// @param value2 �x�N�g��2
	/// @return 
	static bool IsSameVector2(const Vector2 value1, const Vector2 value2);

	//Vector2���m�̉��Z
	const Vector2 operator+(const Vector2 _value)const;
	void operator+=(const Vector2 _value);
	const Vector2 operator-(const Vector2 _value)const;
	void operator-=(const Vector2 _value);
	const Vector2 operator*(const Vector2 _value)const;
	void operator*=(const Vector2 _value);
	const Vector2 operator/(const Vector2 _value)const;
	void operator/=(const Vector2 _value);

	//��̐��ł̉��Z
	template<typename T>
	const Vector2 operator+(const T _value)const
	{
		return{ x + _value,y + _value };
	}
	template<typename T>
	void operator+=(const T _value)
	{
		x += _value;
		y += _value;

	}
	template<typename T>
	const Vector2 operator-(const T _value)const
	{
		return { static_cast<int>(x - _value),static_cast<int>(y - _value) };
	}
	template<typename T>
	void operator-=(const T _value)
	{
		x -= _value;
		y -= _value;
	}
	template<typename T>
	const Vector2 operator*(const T _value)const
	{
		return { static_cast<int>(x * _value),static_cast<int>(y * _value) };
	}
	template<typename T>
	void operator*=(const T _value)
	{
		x *= _value;
		y *= _value;
	}
	template<typename T>
	const Vector2 operator/(const T _value)const
	{
		return { static_cast<int>(x / _value),static_cast<int>(y / _value) };
	}
	template<typename T>
	void operator/=(const T _value)
	{
		x /= _value;
		y /= _value;
	}
};