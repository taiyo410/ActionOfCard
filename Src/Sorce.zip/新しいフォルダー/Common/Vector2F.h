#pragma once
#include "./Vector2.h"

struct Vector2F
{
	//�e���W
	float x;
	float y;

	//Vector2F���m�̔�r
	
	/// @brief Vector2F���m�̔�r
	/// @param value1 �x�N�g��1
	/// @param value2 �x�N�g��2
	/// @return 
	static bool IsVector2F(const Vector2F value1, const Vector2F value2);

	/// @brief Vector2F���m�̒l����������r
	/// @param value1 �x�N�g��1
	/// @param value2 �x�N�g��2
	/// @return 
	static bool IsSameVector2F(const Vector2F value1, const Vector2F value2);

	//Vector2F���m�̉��Z
	const Vector2F operator+(const Vector2F _value)const;
	void operator+=(const Vector2F _value);
	const Vector2F operator-(const Vector2F _value)const;
	void operator-=(const Vector2F _value);
	const Vector2F operator*(const Vector2F _value)const;
	void operator*=(const Vector2F _value);
	const Vector2F operator/(const Vector2F _value)const;
	void operator/=(const Vector2F _value);

	//��̐��ł̉��Z
	template<typename T>
	const Vector2F operator+(const T _value)const
	{
		return{ x + _value,y + _value };
	}
	template<typename T>
	void operator+=(const T _value)
	{
		x += _value;
		y += _value;

	}
	template<typename T>
	const Vector2F operator-(const T _value)const
	{
		return { static_cast<float>(x - _value),static_cast<float>(y - _value) };
	}
	template<typename T>
	void operator-=(const T _value)
	{
		x -= _value;
		y -= _value;
	}
	template<typename T>
	const Vector2F operator*(const T _value)const
	{
		return { static_cast<float>(x * _value),static_cast<float>(y * _value) };
	}
	template<typename T>
	void operator*=(const T _value)
	{
		x *= _value;
		y *= _value;
	}
	template<typename T>
	const Vector2F operator/(const T _value)const
	{
		return { static_cast<float>(x / _value),static_cast<float>(y / _value) };
	}
	template<typename T>
	void operator/=(const T _value)
	{
		x /= _value;
		y /= _value;
	}
};