#pragma once

struct IntVector3
{

public:

	int x;
	int y;
	int z;

	/// @brief // �R���X�g���N�^
	/// @param  
	IntVector3(void);

	/// @brief // �R���X�g���N�^
	/// @param vX 
	/// @param vY 
	/// @param vZ 
	IntVector3(int vX, int vY, int vZ);

	/// @brief �f�X�g���N�^
	/// @param  
	~IntVector3(void);

	//���Z
	const IntVector3 operator+(const IntVector3 _value)const;
	void operator+=(const IntVector3 _value);
	const IntVector3 operator-(const IntVector3 _value)const;
	void operator-=(const IntVector3 _value);
	const IntVector3 operator*(const int _value)const;
	void operator*=(const int _value);
	const IntVector3 operator/(const int _value)const;
	void operator/=(const int _value);
};