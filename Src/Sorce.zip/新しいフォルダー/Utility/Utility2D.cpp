#include <DxLib.h>
#include <cmath>
#include "Utility2D.h"

double Utility2D::Magnitude(const Vector2& v)
{
    return sqrt((v.x * v.x) + (v.y * v.y));
}

int Utility2D::SqrMagnitude(const Vector2& v)
{
    return v.x * v.x + v.y * v.y;
}

double Utility2D::Distance(const Vector2& v1, const Vector2& v2)
{
    return sqrt(pow(v2.x - v1.x, 2) + pow(v2.y - v1.y, 2));
}

Vector2 Utility2D::WorldToMapPos(const Vector2& worldPos, const Vector2& mapSize)
{
    Vector2 mapPos = worldPos;
    mapPos.x = static_cast<int>(worldPos.x / mapSize.x);
    mapPos.y = static_cast<int>(worldPos.y / mapSize.y);
    return mapPos;
}

Vector2 Utility2D::MapToWorldPos(const Vector2& mapPos, const Vector2& mapSize)
{
    Vector2 worldPos = mapPos;
    worldPos.x = static_cast<int>(mapPos.x * mapSize.x);
    worldPos.y = static_cast<int>(mapPos.y * mapSize.y);
    return worldPos;
}

bool Utility2D::IsHitCircles(const Vector2& circlePos1, const float radius1, const Vector2& circlePos2, const float radius2)
{
    // ���S�_�Ԃ�XY�������v�Z
    float dx = static_cast<float>(circlePos1.x - circlePos2.x);  // X�����̍�
    float dy = static_cast<float>(circlePos1.y - circlePos2.y);  // Y�����̍�

    // ���S�ԋ�����2��
    float distanceSq = dx * dx + dy * dy;

    // ���a�̘a��2��
    float radiusSum = radius1 + radius2;
    float radiusSumSq = radiusSum * radiusSum;

    // ������2�� <= ���a�̘a��2�� �� �Փ�
    return distanceSq <= radiusSumSq;
}

void Utility2D::DrawBarGraph(const Vector2& _pos, const Vector2& _size, const float _per, const unsigned int _backColor, const unsigned int _fillColor, const int _offset)
{
    // �w�i�̕`��
    DrawBox(_pos.x, _pos.y, _pos.x + _size.x, _pos.y + _size.y, _backColor, true);
    // �h��Ԃ������̕����v�Z
    int fillWidth = static_cast<int>(_size.x * _per);
	int offset = 2;
    // �h��Ԃ������̕`��
	DrawBox(_pos.x + offset, _pos.y+offset, _pos.x + fillWidth-offset, _pos.y + _size.y-offset, _fillColor, true);
}

void Utility2D::DrawGraphForCenter(const int _img, const Vector2F _pos, const float _sizeScl)
{
    Vector2 size = {};
    GetGraphSize(_img, &size.x, &size.y);
    Vector2F sizeF = { static_cast<float>(size.x),static_cast<float>(size.y) };
    sizeF *= _sizeScl;
    Vector2F leftUpPos = _pos - sizeF;
    Vector2F rightDownPos = _pos + sizeF;
    DrawExtendGraphF(leftUpPos.x, leftUpPos.y, rightDownPos.x, rightDownPos.y, _img,true);
}
