#include "Utility/Utility3D.h"
#include "Utility/UtilityCommon.h"
#include "Manager/Generic/Camera.h"
#include "Manager/Generic/SceneManager.h"
#include "Manager/Resource/ResourceManager.h"
#include "Object/Common/AnimationController.h"
#include "Object/Card/CardSystem.h"
#include "Object/Card/CardDeck.h"
#include "Object/Card/CardBase.h"
#include "Object/Card/CardUIBase.h"
#include "Object/Character/Player/Player.h"
#include "Object/Character/Player/PlayerLogic.h"
#include "Object/Character/Base/ActionBase.h"
#include "./Idle.h"
#include "./Run.h"
#include "./React.h"
#include "./Dodge.h"
#include "./PlayerAction/PlayerCardAttackOneShort.h"
#include "./PlayerAction/PlayerCardAttackOneMiddle.h"
#include "./PlayerAction/PlayerCardAttackTwo.h"
#include "./PlayerAction/PlayerCardAttackThree.h"
#include "./PlayerAction/PlayerCardMagicFire.h"
#include "./PlayerAction/PlayerCardMagicThunder.h"
#include "./PlayerAction/PlayerCardReload.h"
#include "./EnemyAction/EnemyCardAttackJump.h"
#include "./EnemyAction/EnemyCardAttackStomp.h"
#include "./EnemyAction/EnemyCardReload.h"
#include "ActionController.h"

ActionController::ActionController(CharacterBase& _charaObj, LogicBase& _input, Transform& _trans, CardPresenter& _deck, AnimationController& _anim, InputManager::JOYPAD_NO _padNum) :
	character_(_charaObj),
	logic_(_input),
	trans_(_trans),
	cardPresent_(_deck),
	anim_(_anim),
	padNum_(_padNum),
	scnMng_(SceneManager::GetInstance()),
	act_(ACTION_TYPE::IDLE),
	isCardAct_(false),
	stepRotTime_(0.0f),
	speed_(0.0f),
	atkCombos_(),
	movePow_(Utility3D::VECTOR_ZERO),
	moveDir_(Utility3D::VECTOR_ZERO),
	dir_(Utility3D::VECTOR_ZERO)
{
	actionTable_ = {
		{ACTION_TYPE::IDLE, [this]() {mainAction_.emplace(ACTION_TYPE::IDLE,std::make_unique<Idle>(*this,character_)); }},
		{ACTION_TYPE::MOVE, [this]() {mainAction_.emplace(ACTION_TYPE::MOVE,std::make_unique<Run>(*this,character_)); }},
		{ACTION_TYPE::DODGE,[this]() {mainAction_.emplace(ACTION_TYPE::DODGE,std::make_unique<Dodge>(*this,character_)); }},
		{ACTION_TYPE::REACT,[this]() {mainAction_.emplace(ACTION_TYPE::REACT,std::make_unique<React>(*this,character_)); }},
		{ACTION_TYPE::CARD_ATTACK_ONE_MIDDLE,[this]() {
				mainAction_.emplace(ACTION_TYPE::CARD_ATTACK_ONE_MIDDLE,std::make_unique<PlayerCardAttackOneMiddle>(*this,character_,cardPresent_));
		}},
		{ACTION_TYPE::CARD_ATTACK_ONE_SHORT,[this]() {
				mainAction_.emplace(ACTION_TYPE::CARD_ATTACK_ONE_SHORT,std::make_unique<PlayerCardAttackOneShort>(*this,character_,cardPresent_));
		}},
		{ACTION_TYPE::CARD_ATTACK_TWO,[this]() {
				mainAction_.emplace(ACTION_TYPE::CARD_ATTACK_TWO,std::make_unique<PlayerCardAttackTwo>(*this,character_,cardPresent_));
		}},
		{ACTION_TYPE::CARD_ATTACK_THREE,[this]() {
				mainAction_.emplace(ACTION_TYPE::CARD_ATTACK_THREE,std::make_unique<PlayerCardAttackThree>(*this,character_,cardPresent_));
		}},
		{ACTION_TYPE::CARD_MAGIC_FIRE,[this]() {
				mainAction_.emplace(ACTION_TYPE::CARD_MAGIC_FIRE,std::make_unique<PlayerCardMagicFire>(*this,character_,cardPresent_));
		}},
		{ACTION_TYPE::CARD_MAGIC_THUNDER,[this]() {
				mainAction_.emplace(ACTION_TYPE::CARD_MAGIC_THUNDER,std::make_unique<PlayerCardMagicThunder>(*this,character_,cardPresent_));
		}},
		{ACTION_TYPE::CARD_RELOAD,[this]() {
			if (character_.GetCharacterType() == CHARACTER_TYPE::PLAYER)
			{
				mainAction_.emplace(ACTION_TYPE::CARD_RELOAD, std::make_unique<PlayerCardReload>(*this, character_, cardPresent_));
			}
			else
			{
				mainAction_.emplace(ACTION_TYPE::CARD_RELOAD, std::make_unique<EnemyCardReload>(*this, character_, cardPresent_));
			}
		}},
		{ACTION_TYPE::CARD_ATTACK_ENEMY_JUMP,[this]() {
				mainAction_.emplace(ACTION_TYPE::CARD_ATTACK_ENEMY_JUMP,std::make_unique<EnemyCardAttackJump>(*this,character_,cardPresent_));
		}},
		{ACTION_TYPE::CARD_ATTACK_ENEMY_STOMP,[this]() {
				mainAction_.emplace(ACTION_TYPE::CARD_ATTACK_ENEMY_STOMP,std::make_unique<EnemyCardAttackStomp>(*this,character_,cardPresent_));
		}}
	};

	actionStrTable_= {
		{"idle", ACTION_TYPE::IDLE},
		{"run", ACTION_TYPE::MOVE},
		{"react", ACTION_TYPE::REACT},
		{"dodge", ACTION_TYPE::DODGE},
		{"react", ACTION_TYPE::REACT},
		{"attack_1_Middle", ACTION_TYPE::CARD_ATTACK_ONE_MIDDLE},
		{"attack_1_Short", ACTION_TYPE::CARD_ATTACK_ONE_SHORT},
		{"attack_2", ACTION_TYPE::CARD_ATTACK_TWO},
		{"attack_3", ACTION_TYPE::CARD_ATTACK_THREE},
		{"fireMagic", ACTION_TYPE::CARD_MAGIC_FIRE},
		{"thunderMagic", ACTION_TYPE::CARD_MAGIC_THUNDER},
		{"cardReload", ACTION_TYPE::CARD_RELOAD},
		{"stompAttack", ACTION_TYPE::CARD_ATTACK_ENEMY_STOMP},
		{"jumpAttack", ACTION_TYPE::CARD_ATTACK_ENEMY_JUMP },
	};

};

ActionController::~ActionController(void)
{
	StopResource();
	mainAction_.clear();
	subAction_.clear();
	changeAction_.clear();
}

void ActionController::Init(void)
{
	auto cntl = InputManager::CONTROLL_TYPE::ALL;

	//�������̑O�ɒǉ������A�N�V�����̏�����
	mainAction_[act_]->Init();

	isCardAct_ = false;
}

void ActionController::Load(void)
{
	for (auto& action : mainAction_)
	{
		action.second->Load();
	}
}

void ActionController::Update(void)
{
	mainAction_[act_]->Update();

	//���͕����ɉ����������]��
	MoveDirFromInput();

	//�L�����N�^�[�̉�]
	character_.Rotate();

	//�ړ��ʂ̍X�V
	DirAndMovePowUpdate();

	//�J�[�h�̈ړ�
	CardMove();
}


void ActionController::AddAction(void)
{
	const auto datas = ResourceManager::GetInstance().Load(ResourceManager::SRC::CHARA_DATA).jsonData;

	//�ǂݍ��ރL�����N�^�[���
	std::string charaStr = character_.GetObjectName();

	//UseAction��ǂݍ���Œǉ�����
	if (datas[charaStr].contains("UseAction"))
	{
		for (const auto& actData : datas[charaStr]["UseAction"])
		{
			std::string actionName = actData.get<std::string>();
			auto it = actionStrTable_.find(actionName);
			if (it != actionStrTable_.end())
			{
				actionTable_[it->second]();
			}
		}
	}
}

ActionBase& ActionController::GetMainAction(void)
{
	return *mainAction_.at(act_);
}

#ifdef _DEBUG
void ActionController::DrawDebug(void)
{
}
#endif // _DEBUG

const float& ActionController::GetSpd(void) const
{
	return mainAction_.at(act_)->GetSpeed();
}

void ActionController::ChangeAction(const ACTION_TYPE _act)
{
	if (act_ == _act)return;
	ACTION_TYPE prevType = act_;
	mainAction_[prevType]->Release();
	act_ = _act;
	mainAction_[act_]->Init();
}

void ActionController::AnimLoadNotify(const ACTION_LOAD_DATA& animVar)
{
	//�S�s���N���X��Ăɒʒm����
	for(auto& [type,action]:mainAction_)
	{
		action->LoadAnimVar(animVar);
	}
}

void ActionController::DecideCardAction(void)
{
	//�����[�h�J�[�h�ł���΃����[�h�ֈڍs
	if (cardPresent_.GetCardType() == CardBase::CARD_TYPE::RELOAD)
	{
		ChangeAction(ACTION_TYPE::CARD_RELOAD);
		return;
	}
	//�G�̓J�[�h�U��������
	if (character_.GetCharaType() == CHARACTER_TYPE::ENEMY)
	{
		//��D�Ɉړ�
		cardPresent_.PutCard();

		DecideEnemyCardAction();
		return;
	}

	//�v���C���[�̓J�[�h�ɂ���čU����J�ڂ���
	if (cardPresent_.GetCardType() == CardBase::CARD_TYPE::ATTACK)
	{
		//��D�Ɉړ�
		cardPresent_.PutCard();

		//�U���A�N�V�����̑J��
		DesideAttackOne();
	}
	else if (cardPresent_.GetCardType() == CardBase::CARD_TYPE::FIRE)
	{
		//��D�Ɉړ�
		cardPresent_.PutCard();
		ChangeAction(ACTION_TYPE::CARD_MAGIC_FIRE);
	}
	else if (cardPresent_.GetCardType() == CardBase::CARD_TYPE::THUNDER)
	{
		//��D�Ɉړ�
		cardPresent_.PutCard();
		ChangeAction(ACTION_TYPE::CARD_MAGIC_THUNDER);
	}

}
void ActionController::ChangeComboCardAttack(void)
{
	//��̏ꍇ�A�U���s�\�ȏꍇ�̓A�C�h����Ԃ�
	if (atkCombos_.empty()||!IsAttackable()||cardPresent_.GetCardType() == CardBase::CARD_TYPE::RELOAD)
	{
		//�R���{������ɂ���
		if(!atkCombos_.empty()) atkCombos_.pop();
		//�R���{��񂪂Ȃ���΃A�C�h����Ԃ�
		ChangeAction(ACTION_TYPE::IDLE);
		return;
	}

	//���̍U���A�N�V�����ɑJ��
	const ACTION_TYPE& atkType = atkCombos_.front();
	ChangeAction(atkType);

	//�U���Ɏg�p�����J�[�h����D�ɖ߂�
	cardPresent_.PutCard();

	//�R���{�����|�b�v
	atkCombos_.pop();
}

void ActionController::ComboInput(void)
{
	//���݂̃J�[�h�̎�ނ��擾
	const CardBase::CARD_TYPE type = cardPresent_.GetCardType();

	//���͂���Ă��Ȃ��A�܂��́A�R���{�z��ɉ����}������Ă��鎞�͏������΂�
	if (!logic_.GetIsAct().isCardUse||!atkCombos_.empty()||type==CardBase::CARD_TYPE::RELOAD)return;

	//���̒i�K�̍U��������
	if(type==CardBase::CARD_TYPE::ATTACK)
	{
		if(act_==ACTION_TYPE::CARD_ATTACK_ONE_MIDDLE||act_==ACTION_TYPE::CARD_ATTACK_ONE_SHORT)
		{
			atkCombos_.push(ACTION_TYPE::CARD_ATTACK_TWO);
		}
		else if(act_ == ACTION_TYPE::CARD_ATTACK_TWO)
		{
			atkCombos_.push(ACTION_TYPE::CARD_ATTACK_THREE);
		}
	}
	else if(type==CardBase::CARD_TYPE::FIRE)
	{
		atkCombos_.push(ACTION_TYPE::CARD_ATTACK_THREE);
	}
	else
	{
		return;
	}
}

void ActionController::CancelCardActionByDodge(void)
{
	//����ŃA�N�V�����𒆒f
	if (logic_.GetIsAct().isDodge
		&& cardPresent_.GetCardUIState() != CardUIBase::CARD_SELECT::DISITION)
	{
		ChangeAction(ActionController::ACTION_TYPE::DODGE);
	}
}

void ActionController::CardMove(void)
{
	CardUIBase::CARD_SELECT uiState = cardPresent_.GetCardUIState();
	if (uiState != CardUIBase::CARD_SELECT::NONE)return;
	if (IsCardLeftMoveable())
	{
		cardPresent_.RoleRevolver(CardUIBase::CARD_SELECT::LEFT);
	}
	else if (IsCardRightMoveable())
	{
		cardPresent_.RoleRevolver(CardUIBase::CARD_SELECT::RIGHT);
	}
}

const Quaternion ActionController::GetPlayerRotY(void)
{
	return playerRotY_;
}

void ActionController::StopResource(void)
{
}

const bool ActionController::IsCardDecisionControl(void)
{
	const CardUIBase::CARD_SELECT selectState = cardPresent_.GetCardUIState();
	return selectState == CardUIBase::CARD_SELECT::NONE;
}

void ActionController::SetFlinchCnt(const float _flinchTime)
{
	mainAction_[ACTION_TYPE::REACT]->SetFlinchCnt(_flinchTime);
}

void ActionController::MoveDirFromInput(void)
{
	character_.MoveDirFromInput();

	if (mainAction_[act_]->GetIsTurnable())
	{
		//�⊮�p�x�̐ݒ�(���͊p�x�܂ŕ����]������)
		character_.SetGoalRotate();
	}
}

void ActionController::DirAndMovePowUpdate(void)
{
	//�����̍X�V
	moveDir_ = character_.GetRotation().dir_;
	float speed = mainAction_[act_]->GetSpeed();
	//�ړ��ʂ̍X�V
	movePow_ = VScale(moveDir_, speed);
}
const bool ActionController::IsCardLeftMoveable(void)
{
	//�J�[�hUI�̑I�����
	const CardUIBase::CARD_SELECT selectState = cardPresent_.GetCardUIState();

	return logic_.GetIsAct().isCardMoveLeft 
		&& selectState != CardUIBase::CARD_SELECT::RELOAD;
}
const bool ActionController::IsCardRightMoveable(void)
{
	//�J�[�hUI�̑I�����
	CardUIBase::CARD_SELECT selectState = cardPresent_.GetCardUIState();

	return logic_.GetIsAct().isCardMoveRight 
		&& selectState != CardUIBase::CARD_SELECT::RELOAD;
}

void ActionController::DesideAttackOne(void)
{
	//����Ƃ̋������擾
	const float dis = logic_.GetTargetDis();

	//����Ƃ̋��������ȉ��Ȃ�U������
	const float MIDDLE_DIS = 300.0f;

	//�����ɂ���čU���A�N�V�����J��
	if (dis >= MIDDLE_DIS)
	{
		ChangeAction(ACTION_TYPE::CARD_ATTACK_ONE_MIDDLE);
	}
	else
	{
		ChangeAction(ACTION_TYPE::CARD_ATTACK_ONE_SHORT);
	}
}

void ActionController::DecideEnemyCardAction(void)
{
	const float distance = logic_.GetTargetDis();

	//�����_���̐��l�擾
	int rand = GetRand(UtilityCommon::PERCENT_MAX);

	if (distance > ATK_DISTANCE)
	{
		//��������
		if (rand > STOMP_WEIGHT)
		{
			//�G�̊�U��
			ChangeAction(ACTION_TYPE::CARD_ATTACK_ENEMY_STOMP);
		}
		else if (rand < JUMP_WEIGHT)
		{
			//�W�����v
			ChangeAction(ACTION_TYPE::CARD_ATTACK_ENEMY_JUMP);
		}
	}
	else
	{
		//�ߋ�����
		if (rand > STOMP_WEIGHT)
		{
			//�G�̊�U��
			ChangeAction(ACTION_TYPE::CARD_ATTACK_ENEMY_STOMP);
		}
		else if (rand < JUMP_WEIGHT)
		{
			//�W�����v
			ChangeAction(ACTION_TYPE::CARD_ATTACK_ENEMY_JUMP);
		}	
	}
	logic_.SetIsActioning(true);
}

const bool ActionController::IsAttackable(void)
{
	std::vector<CardBase::CARD_TYPE>cardTypes = cardPresent_.GetHandCardType();
	int handCardTypeSize = static_cast<int>(cardPresent_.GetHandCardType().size());
	return handCardTypeSize == 1 && cardTypes[0] == CardBase::CARD_TYPE::ATTACK
		&&cardPresent_.GetCardUIState() != CardUIBase::CARD_SELECT::DISITION
		&& IsCardDecisionControl();
}