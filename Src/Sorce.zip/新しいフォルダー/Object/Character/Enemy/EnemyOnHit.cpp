#include "pch.h"
#include "Utility/Utility3D.h"
#include "Manager/Generic/SceneManager.h"
#include "Manager/Resource/ResourceManager.h"
#include "Object/Common/Geometry/Sphere.h"
#include "Object/Common/Geometry/Capsule.h"
#include "Object/Common/Geometry/Line.h"
#include "Object/Common/Geometry/Model.h"
#include "Object/Card/CardSystem.h"
#include "Object/Character/Base/CharacterBase.h"
#include "Object/Character/Action/ActionController.h"
#include "Object/Character/Base/ItemBase.h"
#include "Object/Character/Base/LogicBase.h"
#include "Object/Character/Base/CharacterOnHitBase.h"
#include "EnemyOnHit.h"

EnemyOnHit::EnemyOnHit(CharacterBase& _chara, VECTOR& _movedPos, VECTOR& _moveDiff
	, ActionController& _action, std::map<ObjectBase::TAG_PRIORITY, std::shared_ptr<Collider>>& _colParam, Transform& _trans):
	CharacterOnHitBase(_chara, _movedPos, _moveDiff, _action, _colParam, _trans)
{
	//���ꂼ��̓��������������i�[����
	using TAG = Collider::TAG;

	//�Փˌ㏈���̊i�[
	colUpdates_ = {
		{ TAG::PLAYER1, [this](const std::weak_ptr<Collider> _hitCol) {CollChara(_hitCol); } },
		{ TAG::NML_ATK, [this](const std::weak_ptr<Collider> _hitCol) {CollNormalAttack(_hitCol); } },
		{ TAG::STAGE, [this](const std::weak_ptr<Collider>_hitCol) {CollStage(_hitCol); } },
		{ TAG::FIRE, [this](const std::weak_ptr<Collider>_hitCol) {CollNormalAttack(_hitCol); } },
		{ TAG::THUNDER, [this](const std::weak_ptr<Collider>_hitCol) {CollNormalAttack(_hitCol); } }
	};
}

EnemyOnHit::~EnemyOnHit(void)
{
}

void EnemyOnHit::Init(void)
{
}

void EnemyOnHit::Load(void)
{
}

#ifdef _DEBUG
void EnemyOnHit::DrawDebug(void)
{
}
#endif // _DEBUG

void EnemyOnHit::CollNormalAttack(const std::weak_ptr<Collider> _hitCol)
{
	//�e�̏����擾
	auto& parent = _hitCol.lock()->GetParent();

	//����̎擾
	auto& item = dynamic_cast<ItemBase&>(parent);
	if (item.GetIsDamage()||actionCtrl_.GetActionType()==ActionController::ACTION_TYPE::CARD_ATTACK_ENEMY_JUMP)return;

	//�_���[�W��^�������Ƃ�m�点��
	item.SetIsDamage();

	DamageFunc();
}

void EnemyOnHit::CollFire(const std::weak_ptr<Collider> _hitCol)
{
	if(actionCtrl_.GetActionType() == ActionController::ACTION_TYPE::CARD_ATTACK_ENEMY_JUMP)return;
	DamageFunc();
}

void EnemyOnHit::CollThunder(const std::weak_ptr<Collider> _hitCol)
{
}

void EnemyOnHit::CollChara(const std::weak_ptr<Collider> _hitCol)
{
	//����Ɠ�������
	isHitTarget_ = true;
}

void EnemyOnHit::DamageFunc(void)
{
	//����L�����̋Z�U���͎擾
	const float& atkPoint = actionCtrl_.GetInput().GetTargetCharacter().lock()->GetMainAction().GetAtkPoint();

	//����̐����Ƃ̍����߂��قǃ_���[�W��ǉ�����
	const int cardDif = CardSystem::GetInstance().GetCardDif();

	int addDam = 0;
	//�J�[�h�V�X�e������J�[�h�̋����̍����擾�B
	cardDif == 0 ? addDam = 0 : addDam = MAX_ADD_DAMAGE - cardDif;

	//�_���[�W�v�Z
	int damage = static_cast<int>(atkPoint) + addDam;
	character_.Damage(damage);

	//�̂����肳����
	actionCtrl_.ChangeAction(ActionController::ACTION_TYPE::REACT);
}
