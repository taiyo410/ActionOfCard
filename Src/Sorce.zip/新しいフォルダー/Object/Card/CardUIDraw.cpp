#include "pch.h"
#include "Utility/UtilityCommon.h"
#include "Manager/Generic/SceneManager.h"
#include "Manager/Resource/FontManager.h"
#include "Manager/Resource/ResourceManager.h"
#include "Renderer/PixelMaterial.h"
#include "Renderer/PixelRenderer.h"
#include "Common/Easing.h"
#include "Object/Card/CardSystem.h"
#include "CardUIDraw.h"

CardUIDraw::CardUIDraw(int& _typeImg,Vector2F& _centerPos, float& _scl):
	typeImg_(_typeImg),
	centerPos_(_centerPos),
	scl_(_scl),
	selectEaseCnt_(),
	shaderSetRevolutionCard_()
{
	//�ʏ�J�[�h�V�F�[�_
	normalCardPSMaterial_ = std::make_unique<PixelMaterial>(ResourceManager::SRC::CARD_NORMAL_PS);
}

CardUIDraw::~CardUIDraw(void)
{
}
void CardUIDraw::Load(void)
{
}

void CardUIDraw::Init(void)
{
	//�摜�T�C�Y�擾
	GetGraphSizeF(typeImg_, &size_.x, &size_.y);
	halfSize_ = size_ / 2.0f;

	//����̍��W
	rightTopPos_ = centerPos_ - halfSize_ * scl_;

	//�E���̍��W
	leftDownPos_ = centerPos_ + halfSize_ * scl_;

	Vector2 rightTopPos = {static_cast<int>(rightTopPos_.x),static_cast<int>(rightTopPos_.y)};

	easing_ = std::make_unique<Easing>();

	//�ʏ�J�[�h�V�F�[�_
	normalCardPSMaterial_ = std::make_unique<PixelMaterial>(ResourceManager::SRC::CARD_NORMAL_PS);
	normalCardPSMaterial_->AddTextureBuf(typeImg_);
	normalCardPSMaterial_->AddConstBuf({ 0.0f,0.0f, 0.0f,1.0f });		//�J�[�h�̐F
	normalCardPSMaterial_->AddConstBuf({ 1.0f,0.0f, 0.0f,0.0f });		//�T�C�Y
	normalCardPSRenderer_ = std::make_unique<PixelRenderer>(*normalCardPSMaterial_);
	normalCardPSRenderer_->MakeSquareVertex(rightTopPos_, size_);

	//�����[�h�J�[�h
	reloadCardPSMaterial_= std::make_unique<PixelMaterial>(ResourceManager::SRC::CARD_RELOAD_PS);
	reloadCardPSMaterial_->AddTextureBuf(ResourceManager::GetInstance().Load(ResourceManager::SRC::RELOAD_GAUGE).handleId_);
	reloadCardPSMaterial_->AddConstBuf({ 0.0f,0.0f, 0.0f,1.0f });		//�J�[�h�̐F
	reloadCardPSMaterial_->AddConstBuf({ 1.0f,0.0f, 0.0f,1.0f });		//�A�E�g���C���̐F
	reloadCardPSRenderer_ = std::make_unique<PixelRenderer>(*reloadCardPSMaterial_);
	reloadCardPSRenderer_->MakeSquareVertex(rightTopPos_, size_);

	//�I��g
	selectFramePSMaterial_ = std::make_unique<PixelMaterial>(ResourceManager::SRC::CARD_SELECT_PS);
	selectFramePSMaterial_->AddTextureBuf(typeImg_);
	selectFramePSMaterial_->AddConstBuf({ 0.0f,0.0f, 0.0f,0.0f });		//�J�[�h�̐F
	selectFramePSRenderer_ = std::make_unique<PixelRenderer>(*selectFramePSMaterial_);
	selectFramePSRenderer_->MakeSquareVertexFromCenter(centerPos_, size_);

}

void CardUIDraw::Update(void)
{
	selectFramePSMaterial_->SetConstBuf(NORMAL_CARD_CONST_BUF, { SceneManager::GetInstance().GetTotalTime(),1.0f, 1.0f,0.0f});
	SelectFrameEasing();
}

void CardUIDraw::Draw(void)
{
	DrawCard();
}

void CardUIDraw::DrawSelectedFrame(void)
{
	//�I��g�`��
	selectFramePSRenderer_->DrawFromCenter(centerPos_.x, centerPos_.y);
}

void CardUIDraw::DrawSelectCard(void)
{
	//����������`�悷��
	float totalTime = SceneManager::GetInstance().GetTotalTime();
	normalCardPSMaterial_->SetConstBuf(NORMAL_CARD_CONST_BUN_NUM, { SELECT_FOG_STRENGTH,totalTime, 0.0f,1.0f });		//�J�[�h�̐F

	//�J�[�h�`��
	DrawCard();
}

void CardUIDraw::DrawReverseColorCard(void)
{
}

void CardUIDraw::DrawCard(void)
{
	//�摜�T�C�Y�擾
	GetGraphSizeF(typeImg_, &size_.x, &size_.y);

	//�n�[�t�T�C�Y�v�Z
	halfSize_ = size_ / 2.0f;

	//����̍��W
	Vector2F rightTopPos = centerPos_ - halfSize_ * scl_;

	//�J�[�h�̐F
	const CardSystem::ORDER_RULE judgeRule = CardSystem::GetInstance().GetJudgeRule();
	float setShaderCol = judgeRule == CardSystem::ORDER_RULE::NORMAL ? 0.0f : 1.0f;
	normalCardPSMaterial_->SetConstBuf(NORMAL_CARD_CONST_BUN_NUM, { 0.0f,0.0f, setShaderCol,1.0f });		

	//�����_���[�ɃZ�b�g
	normalCardPSRenderer_->SetSize(size_ * scl_);
	normalCardPSRenderer_->Draw(rightTopPos.x, rightTopPos.y);
}

void CardUIDraw::SelectFrameEasing(void)
{
	//�T�C�Y
	Vector2F size = easing_->EaseFunc(size_ - SELECT_CARD_FRAME_MOVE_AMOUNT,
		size_, selectEaseCnt_ / SELECT_CARD_FRAME_EASING_TIME,
		Easing::EASING_TYPE::QUAD_BACK);

	//�C�[�W���O�J�E���g�X�V
	selectEaseCnt_ += SceneManager::GetInstance().GetDeltaTime();
	selectEaseCnt_ > SELECT_CARD_FRAME_EASING_TIME ? selectEaseCnt_ = 0.0f : selectEaseCnt_;

	//�V�F�[�_�[�ɒl�Z�b�g
	selectFramePSRenderer_->SetSize(size);
}

void CardUIDraw::DrawReloadGauge(const float& _reloadPer)
{
	//�摜�T�C�Y�擾
	GetGraphSizeF(typeImg_, &size_.x, &size_.y);

	halfSize_ = size_ / 2.0f;

	//����̍��W
	Vector2F rightTopPos = centerPos_ - halfSize_ * scl_;

	reloadCardPSMaterial_->SetConstBuf(RELOAD_PER_CONST_BUF_SIZE, { 0.0f,0.0f,_reloadPer,0.0f });
	reloadCardPSRenderer_->SetSize(size_ * scl_);
	reloadCardPSRenderer_->Draw(rightTopPos.x, rightTopPos.y);
}
