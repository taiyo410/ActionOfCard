#include "pch.h"
#include "Manager/Generic/InputManager.h"
#include "Manager/Generic/SceneManager.h"
#include "Manager/Resource/ResourceManager.h"
#include "Manager/Generic/UIManager.h"
#include "Renderer/PixelMaterial.h"
#include "Renderer/PixelRenderer.h"
#include "GameEventRevolutionScene.h"

GameEventRevolutionScene::GameEventRevolutionScene(void):
	fadeCnt_()
{
	//�X�V�֐��̃Z�b�g
	updateFunc_ = [this]() {NormalUpdate(); };

	//�`��֐��̃Z�b�g
	drawFunc_ = [this]() {NormalDraw(); };

	postEffectScreen_ = MakeScreen(Application::SCREEN_SIZE_X, Application::SCREEN_SIZE_Y, true);
}

GameEventRevolutionScene::~GameEventRevolutionScene(void)
{
}

void GameEventRevolutionScene::Load(void)
{
	material_ = std::make_unique<PixelMaterial>(ResourceManager::SRC::REVOLUTION_POSTEFF_PS);

	//���C���X�N���[��
	const int mainScreen = scnMng_.GetMainScreen();
	material_->AddTextureBuf(mainScreen);

	//�}�X�N�摜
	const int maskImg = resMng_.Load(ResourceManager::SRC::REVERSE_FADE_MASK).handleId_;
	material_->AddTextureBuf(maskImg);

	material_->AddConstBuf({ fadeCnt_ ,0.0f,0.0f,0.0f });

	renderer_ = std::make_shared<PixelRenderer>(*material_);
	renderer_->MakeScreenVertex();
}

void GameEventRevolutionScene::Init(void)
{
	//�|�X�g�G�t�F�N�g��SceneManager����
	scnMng_.SetPostEffect(renderer_);
	revolutionFadeFunc_ = [this]() {RevolutionFadeIn(); };
	fadeCnt_ = 0.0f;
	waitCnt_ = 0.0f;
}

void GameEventRevolutionScene::Release(void)
{
}

void GameEventRevolutionScene::NormalUpdate(void)
{
	revolutionFadeFunc_();

	material_->SetConstBuf(0, { fadeCnt_/FADE_TIME ,0.0f,0.0f,0.0f });
}

void GameEventRevolutionScene::NormalDraw(void)
{
	const int mainScreen = scnMng_.GetMainScreen();
	material_->SetTextureBuf(0, mainScreen);
}

void GameEventRevolutionScene::RevolutionFadeIn(void)
{
	//�f�o�b�O�Ŋv�����L�[�ŋN����
	if (inputMng_.IsTrgDown(KEY_INPUT_1))
	{
		revolutionFadeFunc_ = [this]() {RevolutionFadeOut(); };
		return;
	}
	if (fadeCnt_ <= FADE_TIME)
	{
		fadeCnt_ += scnMng_.GetDeltaTime();
		return;
	}

	//�t�F�[�h�I����A��莞�ԑҋ@
	if (waitCnt_ > WAIT_TIME)
	{
		revolutionFadeFunc_ = [this]() {RevolutionFadeOut(); };
	}
	waitCnt_ += scnMng_.GetDeltaTime();
}

void GameEventRevolutionScene::RevolutionFadeOut(void)
{
	if (fadeCnt_ > 0.0f)
	{
		fadeCnt_ -= scnMng_.GetDeltaTime();
	}
	else
	{
		scnMng_.DeletePostEffect(renderer_);
		scnMng_.PopScene();
		return;
	}
}

void GameEventRevolutionScene::OnSceneEnter(void)
{
	//�|�X�g�G�t�F�N�g��SceneManager����
	scnMng_.SetPostEffect(renderer_);
}
