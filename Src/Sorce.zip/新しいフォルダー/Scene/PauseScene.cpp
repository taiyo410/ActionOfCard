#include <DxLib.h>
#include "Utility/UtilityCommon.h"
#include "Application.h"
#include "Manager/Resource/ResourceManager.h"
#include "Manager/Resource/FontManager.h"
#include "Manager/Generic/SceneManager.h"
#include "Manager/Generic/InputManager.h"
#include "Manager/Generic/InputManagerS.h"
#include "./PauseScene.h"

PauseScene::PauseScene(void):
	pauseFont_(UtilityCommon::INITIAL_HANDLE),
	selectIndex_()
{
	//�X�V�֐��̃Z�b�g
	updateFunc_ = [this]() {NormalUpdate(); };

	//�`��֐��̃Z�b�g
	drawFunc_ = [this]() {NormalDraw(); };
	
	//���X�g���Ƃɏ����𕪂���
	listFuncTable_ =
	{
		//�|�[�Y���������đO�̃V�[���ɖ߂�
		{LIST::RESUME,[this]() {scnMng_.PopScene(); }},	
		//�^�C�g���V�[���ɖ߂�
		{LIST::TITLE,[this](){scnMng_.ChangeScene(SceneManager::SCENE_ID::TITLE);}},
		//�Q�[�����I������
		{LIST::GAME_END,[this](){Application::GetInstance().IsGameEnd(); }}

	};
}

PauseScene::~PauseScene(void)
{
}

void PauseScene::Load(void)
{
	pauseFont_ = CreateFontToHandle(FontManager::FONT_APRIL_GOTHIC.c_str(), FONT_SIZE, FONT_THICK);
}

void PauseScene::Init(void)
{	
	
}
void PauseScene::Release(void)
{

}
void PauseScene::NormalUpdate(void)
{
	if (inputMng_.IsTrgDown(KEY_INPUT_ESCAPE))
	{
		//�V�[����߂�
		scnMng_.PopScene();
		return;
	}
	else if (inputMng_.IsTrgDown(KEY_INPUT_DOWN)||inputMngS_.IsTrgDown(INPUT_EVENT::DOWN))
	{
		selectIndex_ = (selectIndex_ - 1 + LIST_MAX) % LIST_MAX;
	}
	else if (inputMng_.IsTrgDown(KEY_INPUT_UP) || inputMngS_.IsTrgDown(INPUT_EVENT::UP))
	{
		selectIndex_ = (selectIndex_ + 1) % LIST_MAX;
	}
	else if (inputMng_.IsTrgDown(KEY_INPUT_RETURN)||inputMngS_.IsTrgDown(INPUT_EVENT::OK))
	{
		listFuncTable_[static_cast<LIST>(selectIndex_)]();
		return;
	}
}

void PauseScene::NormalDraw(void)
{
	static constexpr int MARGINT = 50;
	static constexpr int OFFSET_Y = 100;

	SetDrawBlendMode(DX_BLENDMODE_ALPHA, PAUSE_ALPHA);
	DrawBox(
		MARGINT,
		MARGINT,
		Application::SCREEN_SIZE_X- MARGINT,
		Application::SCREEN_SIZE_Y- MARGINT,
		UtilityCommon::WHITE,
		true);	

	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);

	for (int i = 0; i < LIST_MAX; ++i)
	{
		//�J���[��ݒ�
		int color = UtilityCommon::BLUE;
		if (i == selectIndex_)
		{
			color = UtilityCommon::RED; // �I�𒆂͐ԐF
		}

		//���W�ʒu��ݒ�
		int posX = static_cast<int>(Application::SCREEN_HALF_X - pauseList_[i].length() * FONT_SIZE / 2);
		int posY = Application::SCREEN_HALF_Y - OFFSET_Y * i;

		//�������`��
		DrawFormatStringToHandle(
			posX,
			posY,
			color,
			pauseFont_,
			pauseList_[i].c_str());
	}
}

void PauseScene::OnSceneEnter(void)
{
	updateFunc_ = [this]() {NormalUpdate(); };
	drawFunc_ = [this]() {NormalDraw(); };
}
