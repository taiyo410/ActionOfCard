#include <string>
#include <DxLib.h>
#include "Utility/UtilityCommon.h"
#include "Utility/UtilityDraw.h"
#include "Application.h"
#include "Common/Easing.h"
#include "Manager/Generic/SceneManager.h"
#include "Manager/Generic/InputManager.h"
#include "Manager/Generic/InputManagerS.h"
#include "Manager/Generic/Camera.h"
#include "Manager/Resource/ResourceManager.h"
#include "Manager/Resource/SoundManager.h"
#include "Manager/Resource/FontManager.h"
#include "GameClearScene.h"

GameClearScene::GameClearScene(void):
	soundMng_(SoundManager::GetInstance()),
	easeCnt_(0.0f),
	strYPos_(SceneBase::BACK_TITLE_STRING_POS_Y)
{
	//�X�V�֐��̃Z�b�g
	updateFunc_ = [this]() {LoadingUpdate(); };

	//�`��֐��̃Z�b�g
	drawFunc_ = [this]() {LoadingDraw(); };

	//�J�����̕ύX
	SceneManager::GetInstance().GetCamera().lock()->ChangeMode(Camera::MODE::FIXED_POINT);
}

GameClearScene::~GameClearScene(void)
{
}

void GameClearScene::Load(void)
{
	//�摜�̃��[�h
	imgGameClear_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::GAME_CLEAR_IMG).handleId_;

	//�t�H���g�̓o�^
	buttonFontHandle_ = CreateFontToHandle(FontManager::FONT_APRIL_GOTHIC.c_str(), FONT_SIZE, 0);

	//BGM���[�h
	resMng_.Load(ResourceManager::SRC::GAME_CLEAR_BGM);
}

void GameClearScene::Init(void)
{
	//BGM�Đ�
	soundMng_.GetInstance().Play(ResourceManager::SRC::GAME_CLEAR_BGM, SoundManager::PLAYTYPE::LOOP);

	easing_ = std::make_unique<Easing>();
}

void GameClearScene::Release(void)
{
	soundMng_.Stop(ResourceManager::SRC::GAME_CLEAR_BGM);
}

void GameClearScene::NormalUpdate(void)
{
	// �V�[���J��
	if (inputMng_.IsTrgDown(KEY_INPUT_SPACE)|| inputMngS_.IsTrgDown(INPUT_EVENT::OK))
	{
		SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::TITLE);
	}
	const float LIMIT = SceneBase::BACK_TITLE_STRING_POS_Y - BACK_TITLE_STRING_POS_EASE_LIMIT;
	strYPos_ = easing_->EaseFunc(SceneBase::BACK_TITLE_STRING_POS_Y, LIMIT, easeCnt_ / EASING_TIME, Easing::EASING_TYPE::QUAD_BACK);
	easeCnt_ += scnMng_.GetDeltaTime();
	if (easeCnt_ > EASING_TIME)
	{
		easeCnt_ = 0.0f;
	}
}

void GameClearScene::NormalDraw(void)
{
	//�Q�[���N���A�摜
	DrawExtendGraph(0, 0, Application::SCREEN_SIZE_X, Application::SCREEN_SIZE_Y, imgGameClear_, true);

	//B�{�^���A�X�y�[�X�L�[�Ń^�C�g���ɖ߂�̕`��
	UtilityDraw::DrawStringCenter(
		Application::SCREEN_HALF_X,
		static_cast<int>(strYPos_),
		BACK_TITLE_SCENE_STR,
		UtilityCommon::WHITE,
		buttonFontHandle_
	);

}

void GameClearScene::OnSceneEnter(void)
{
	//�����ύX
	updateFunc_ = [this]() {NormalUpdate(); };
	drawFunc_ = [this]() {NormalDraw(); };

	//�O�̂��߃J�����̃��[�h��NONE��Ԃ�
	scnMng_.GetCamera().lock()->ChangeMode(Camera::MODE::FIXED_POINT);
}
