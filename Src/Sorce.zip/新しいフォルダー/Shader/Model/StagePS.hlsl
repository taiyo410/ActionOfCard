// VS/PS����

#include "../Common/VertexToPixelHeader.hlsli"

// IN

#define PS_INPUT VertexToPixelLit

//PS

#include "../Common/Pixel/PixelShader3DHeader.hlsli"
 
Texture2D Noise : register(t3);
 
// �萔�o�b�t�@�F�X���b�g4�Ԗ�(b4�Ə���)

cbuffer cbParam : register(b4)
{
    //float g_time;

    //float3 dummy;
}
 
 
float4 main(PS_INPUT PSInput) : SV_TARGET
{

    float2 uv = PSInput.uv;

    float4 color = diffuseMapTexture.Sample(diffuseMapSampler, uv);
 
    return color;

}
 