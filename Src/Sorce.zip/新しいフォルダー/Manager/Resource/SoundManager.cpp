#include <DxLib.h>
#include <cassert>
#include "Manager/Resource/ResourceManager.h"
#include "Application.h"
#include "SoundManager.h"
SoundManager::SoundManager(void):
	resMng_(ResourceManager::GetInstance()),
    dummy_()
{  
	// ���ʂ̏�����
	for (int i = 0; i < TYPE_MAX; ++i)
	{
		volume_[i] = DEFAULT_VOLUME;
	}
}

SoundManager::~SoundManager(void)
{
}

void SoundManager::Init(void)
{
}

void SoundManager::Play(const SRC _src, const PLAYTYPE _playType)
{
	//�������ǂݍ��܂�Ă��Ȃ��ꍇ�̓G���[
	int handleId = resMng_.GetResource(_src).handleId_;
	assert(handleId == -1 && NOT_LOAD_ERROR_MESSAGE);

    //�������Đ��ς݂����ׂ�
	if (CheckSoundMem(handleId) == 1 &&
        _playType != PLAYTYPE::BACK)
	{
		Stop(_src);  // �Đ��ς݂Ȃ��~
	}

    //�����̍Đ�
    int i=PlaySoundMem(handleId, GetPlayType(_playType));
}

void SoundManager::Stop(const SRC _src)
{
    //�����̒�~
    StopSoundMem(resMng_.GetResource(_src).handleId_);
}

bool SoundManager::IsPlay(const SRC _src) const
{
    const auto res = resMng_.GetResource(_src);

    if (res.handleId_ == -1)
    {
        return false; // ������Ȃ��ꍇ�͖��Đ��Ƃ���
    }
    return CheckSoundMem(res.handleId_) == 1;
}

const void SoundManager::SetLoadedSoundsVolume(void)
{
    for (int i = 0; i < TYPE_MAX; i++) 
    {
        SetSystemVolume(volume_[i], static_cast<TYPE>(i)); 
    }
}

void SoundManager::SetSoundVolumeSRC(const SRC _src, const float _volumePercent)
{
    //���\�[�X�̎擾
	const ResourceData res = resMng_.GetResource(_src);
    if (res.type_ == ResourceData::TYPE::NONE)
    {
        return; // ������Ȃ��ꍇ�͏������Ȃ�
    }

	int volume = static_cast<int>(VOLUME_MAX * _volumePercent);
    //���ʐݒ�
	ChangeVolumeSoundMem(volume, res.handleId_);
}

void SoundManager::SetSystemVolume(const float _volumePercent, const TYPE _type)
{    
    //�^�ϊ�
	const int type = static_cast<int>(_type);
    //���ʐݒ�
    volume_[type] = _volumePercent;
   
	const auto sounds = resMng_.GetSoundResources(_type);
    //���ʒ���
	for (const auto& pair : sounds)
	{
        int volume = static_cast<int>(VOLUME_MAX * volume_[type]);
        ChangeVolumeSoundMem(volume, pair->handleId_);
	}
}

int SoundManager::GetPlayType(const PLAYTYPE _playType)
{
    switch (_playType)
    {
    case PLAYTYPE::NORMAL:
        return DX_PLAYTYPE_NORMAL;
        break;

    case PLAYTYPE::LOOP:
        return DX_PLAYTYPE_LOOP;
        break;

    case PLAYTYPE::BACK:
        return DX_PLAYTYPE_BACK;
        break;

    default:
        return DX_PLAYTYPE_NORMAL;
        break;
    }
}

void SoundManager::AllStop(void)
{
    std::vector sounds = resMng_.GetSoundResources();
    for (const auto& sound : sounds)
    {
        //�Đ�����Ă��Ȃ��A�������̓G���[�����������΂�
        if (CheckSoundMem(sound->handleId_) <= 0)continue;
        StopSoundMem(sound->handleId_);
    }
}
