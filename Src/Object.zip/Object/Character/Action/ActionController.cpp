#include"../Utility/Utility3D.h"
#include"../Utility/UtilityCommon.h"
#include"../Player/Player.h"
#include"../Player/PlayerLogic.h"
#include "../../../Manager/Generic/Camera.h"
#include "../../../Manager/Generic/SceneManager.h"
#include "../../../Manager/Resource/ResourceManager.h"
#include"../Object/Card/CardSystem.h"
#include "../../../Object/Common/AnimationController.h"
#include"../../Card/CardDeck.h"
#include"../../Card/CardBase.h"
#include"../../Card/CardUIBase.h"
#include"../Base/ActionBase.h"
#include"../Action/Idle.h"
#include"../Action/Run.h"
#include"../Action/React.h"
#include"../Action/Dodge.h"
#include"../Action/PlayerAction/PlayerCardAttackOneShort.h"
#include"../Action/PlayerAction/PlayerCardAttackOneMiddle.h"
#include"../Action/PlayerAction/PlayerCardAttackTwo.h"
#include"../Action/PlayerAction/PlayerCardAttackThree.h"
#include"../Action/PlayerAction/PlayerCardMagicFire.h"
#include"../Action/PlayerAction/PlayerCardReload.h"
#include"../Action/EnemyAction/EnemyCardAttackJump.h"
#include"../Action/EnemyAction/EnemyCardAttackStomp.h"

#include "ActionController.h"

ActionController::ActionController(CharacterBase& _charaObj, LogicBase& _input, Transform& _trans, CardPresenter& _deck, AnimationController& _anim, InputManager::JOYPAD_NO _padNum) :
	charaObj_(_charaObj),
	logic_(_input),
	trans_(_trans),
	cardPresent_(_deck),
	anim_(_anim),
	padNum_(_padNum),
	scnMng_(SceneManager::GetInstance()),
	act_(ACTION_TYPE::IDLE),
	isCardAct_(false),
	stepRotTime_(0.0f),
	speed_(0.0f),
	atkCombos_(),
	movePow_(Utility3D::VECTOR_ZERO),
	moveDir_(Utility3D::VECTOR_ZERO),
	dir_(Utility3D::VECTOR_ZERO)
{
	actionTable_ = {
		{ACTION_TYPE::IDLE, [this]() {mainAction_.emplace(ACTION_TYPE::IDLE,std::make_unique<Idle>(*this,charaObj_)); }},
		{ACTION_TYPE::MOVE, [this]() {mainAction_.emplace(ACTION_TYPE::MOVE,std::make_unique<Run>(*this,charaObj_)); }},
		{ACTION_TYPE::DODGE,[this]() {mainAction_.emplace(ACTION_TYPE::DODGE,std::make_unique<Dodge>(*this,charaObj_)); }},
		{ACTION_TYPE::REACT,[this]() {mainAction_.emplace(ACTION_TYPE::REACT,std::make_unique<React>(*this,charaObj_)); }},
		{ACTION_TYPE::CARD_ATTACK_ONE_MIDDLE,[this]() {
			if (charaObj_.GetCharaType() == CHARACTER_TYPE::PLAYER)
			{
				mainAction_.emplace(ACTION_TYPE::CARD_ATTACK_ONE_MIDDLE,std::make_unique<PlayerCardAttackOneMiddle>(*this,charaObj_,cardPresent_));
			}
		}},
		{ACTION_TYPE::CARD_ATTACK_ONE_SHORT,[this]() {
			if (charaObj_.GetCharaType() == CHARACTER_TYPE::PLAYER)
			{
				mainAction_.emplace(ACTION_TYPE::CARD_ATTACK_ONE_SHORT,std::make_unique<PlayerCardAttackOneShort>(*this,charaObj_,cardPresent_));
			}
		}},
		{ACTION_TYPE::CARD_ATTACK_TWO,[this]() {
			if (charaObj_.GetCharaType() == CHARACTER_TYPE::PLAYER)
			{
				mainAction_.emplace(ACTION_TYPE::CARD_ATTACK_TWO,std::make_unique<PlayerCardAttackTwo>(*this,charaObj_,cardPresent_));
			}
		}},
		{ACTION_TYPE::CARD_ATTACK_THREE,[this]() {
			if (charaObj_.GetCharaType() == CHARACTER_TYPE::PLAYER)
			{
				mainAction_.emplace(ACTION_TYPE::CARD_ATTACK_THREE,std::make_unique<PlayerCardAttackThree>(*this,charaObj_,cardPresent_));
			}
		}},
		{ACTION_TYPE::CARD_MAGIC_FIRE,[this]() {
			if (charaObj_.GetCharaType() == CHARACTER_TYPE::PLAYER)
			{
				mainAction_.emplace(ACTION_TYPE::CARD_MAGIC_FIRE,std::make_unique<PlayerCardMagicFire>(*this,charaObj_,cardPresent_));
			}
		}},
		{ACTION_TYPE::CARD_RELOAD,[this]() {
			if (charaObj_.GetCharaType() == CHARACTER_TYPE::PLAYER)
			{
				mainAction_.emplace(ACTION_TYPE::CARD_RELOAD,std::make_unique<PlayerCardReload>(*this,charaObj_,cardPresent_));
			}
		}},
		{ACTION_TYPE::CARD_ATTACK_ENEMY_JUMP,[this]() {
			if (charaObj_.GetCharaType() == CHARACTER_TYPE::ENEMY)
			{
				mainAction_.emplace(ACTION_TYPE::CARD_ATTACK_ENEMY_JUMP,std::make_unique<EnemyCardAttackJump>(*this,charaObj_,cardPresent_));
			}
		}},
		{ACTION_TYPE::CARD_ATTACK_ENEMY_STOMP,[this]() {
			if (charaObj_.GetCharaType() == CHARACTER_TYPE::ENEMY)
			{
				mainAction_.emplace(ACTION_TYPE::CARD_ATTACK_ENEMY_STOMP,std::make_unique<EnemyCardAttackStomp>(*this,charaObj_,cardPresent_));
			}
		}}
	};

};

ActionController::~ActionController(void)
{
	StopResource();
	mainAction_.clear();
	subAction_.clear();
	changeAction_.clear();
}

void ActionController::Init(void)
{
	auto cntl = InputManager::CONTROLL_TYPE::ALL;

	//�������̑O�ɒǉ������A�N�V�����̏�����
	mainAction_[act_]->Init();

	isCardAct_ = false;
}

void ActionController::Load(void)
{
	for (auto& action : mainAction_)
	{
		action.second->Load();
	}
}

void ActionController::Update(void)
{
	mainAction_[act_]->Update();

	//���͕����ɉ����������]��
	MoveDirFromInput();

	//�L�����N�^�[�̉�]
	charaObj_.Rotate();

	//�ړ��ʂ̍X�V
	DirAndMovePowUpdate();

	//�J�[�h�̈ړ�
	CardMove();
}


void ActionController::AddAction(std::vector<ACTION_TYPE> _types)
{
	for (auto& type : _types)
	{
		actionTable_[type]();
	}
}

ActionBase& ActionController::GetMainAction(void)
{
	return *mainAction_.at(act_);
}

#ifdef _DEBUG
void ActionController::DrawDebug(void)
{
}
#endif // _DEBUG

const float& ActionController::GetSpd(void) const
{
	return mainAction_.at(act_)->GetSpeed();
}

void ActionController::ChangeAction(const ACTION_TYPE _act)
{
	if (act_ == _act)return;
	ACTION_TYPE prevType = act_;
	mainAction_[prevType]->Release();
	act_ = _act;
	mainAction_[act_]->Init();
}

void ActionController::AnimLoadNotify(const ACTION_LOAD_DATA& animVar)
{
	//�S�s���N���X��Ăɒʒm����
	for(auto& [type,action]:mainAction_)
	{
		action->LoadAnimVar(animVar);
	}
}

void ActionController::DesideCardAction(void)
{
	//�G�̓J�[�h�U��������
	if (charaObj_.GetCharaType() == CHARACTER_TYPE::ENEMY)
	{
		//��D�Ɉړ�
		cardPresent_.PutCard();

		DesideEnemyCardAction();
		return;
	}

	//�v���C���[�̓J�[�h�ɂ���čU����J�ڂ���
	if (cardPresent_.GetCardType() == CardBase::CARD_TYPE::ATTACK)
	{
		//��D�Ɉړ�
		cardPresent_.PutCard();

		//�U���A�N�V�����̑J��
		DesideAttackOne();
	}
	else if (cardPresent_.GetCardType() == CardBase::CARD_TYPE::FIRE)
	{
		ChangeAction(ACTION_TYPE::CARD_MAGIC_FIRE);
	}
	else if(cardPresent_.GetCardType() == CardBase::CARD_TYPE::RELOAD)
	{
		ChangeAction(ACTION_TYPE::CARD_RELOAD);
	}
}
void ActionController::ChangeComboCardAttack(void)
{
	//��̏ꍇ�A�U���s�\�ȏꍇ�̓A�C�h����Ԃ�
	if (atkCombos_.empty()||!IsAttacable()||cardPresent_.GetCardType() == CardBase::CARD_TYPE::RELOAD)
	{
		//�R���{��񂪂Ȃ���΃A�C�h����Ԃ�
		ChangeAction(ACTION_TYPE::IDLE);
		return;
	}

	//���̍U���A�N�V�����ɑJ��
	const ACTION_TYPE& atkType = atkCombos_.front();
	ChangeAction(atkType);

	//�U���Ɏg�p�����J�[�h����D�ɖ߂�
	cardPresent_.PutCard();


	//�R���{�����|�b�v
	atkCombos_.pop();
}

void ActionController::ComboInput(void)
{
	//���݂̃J�[�h�̎�ނ��擾
	const CardBase::CARD_TYPE type = cardPresent_.GetCardType();

	//���͂���Ă��Ȃ��A�܂��́A�R���{�z��ɉ����}������Ă��鎞�͏������΂�
	if (!logic_.GetIsAct().isCardUse||!atkCombos_.empty()||type==CardBase::CARD_TYPE::RELOAD)return;

	//���̒i�K�̍U��������
	if(type==CardBase::CARD_TYPE::ATTACK)
	{
		if(act_==ACTION_TYPE::CARD_ATTACK_ONE_MIDDLE||act_==ACTION_TYPE::CARD_ATTACK_ONE_SHORT)
		{
			atkCombos_.push(ACTION_TYPE::CARD_ATTACK_TWO);
		}
		else if(act_ == ACTION_TYPE::CARD_ATTACK_TWO)
		{
			atkCombos_.push(ACTION_TYPE::CARD_ATTACK_THREE);
		}
	}
	else if(type==CardBase::CARD_TYPE::FIRE)
	{
		atkCombos_.push(ACTION_TYPE::CARD_ATTACK_THREE);
	}
	else
	{
		return;
	}
}

void ActionController::CancelCardActionByDodge(void)
{
	//����ŃA�N�V�����𒆒f
	if (logic_.GetIsAct().isDodge
		&& cardPresent_.GetCardUIState() != CardUIBase::CARD_SELECT::DISITION)
	{
		ChangeAction(ActionController::ACTION_TYPE::DODGE);
	}
}

void ActionController::CardMove(void)
{
	CardUIBase::CARD_SELECT uiState = cardPresent_.GetCardUIState();
	//if (uiState == CardUIBase::CARD_SELECT::DISITION
	//	|| uiState == CardUIBase::CARD_SELECT::LEFT
	//	|| uiState == CardUIBase::CARD_SELECT::RIGHT
	//	|| uiState == CardUIBase::CARD_SELECT::RELOAD)return;
	if (uiState != CardUIBase::CARD_SELECT::NONE)return;
	if (IsCardLeftMoveable())
	{
		cardPresent_.RoleRevolver(CardUIBase::CARD_SELECT::LEFT);
	}
	else if (IsCardRightMoveable())
	{
		cardPresent_.RoleRevolver(CardUIBase::CARD_SELECT::RIGHT);
	}
}

const Quaternion ActionController::GetPlayerRotY(void)
{
	return playerRotY_;
}

void ActionController::StopResource(void)
{
}

const bool ActionController::IsCardDecisionControl(void)
{
	const CardUIBase::CARD_SELECT selectState = cardPresent_.GetCardUIState();
	return selectState == CardUIBase::CARD_SELECT::NONE;
}

void ActionController::SetFlinchCnt(const float _flinchTime)
{
	mainAction_[ACTION_TYPE::REACT]->SetFlinchCnt(_flinchTime);
}

void ActionController::MoveDirFromInput(void)
{
	charaObj_.MoveDirFromInput();

	if (mainAction_[act_]->GetIsTurnable())
	{
		//�⊮�p�x�̐ݒ�(���͊p�x�܂ŕ����]������)
		charaObj_.SetGoalRotate();
	}
}

void ActionController::DirAndMovePowUpdate(void)
{
	//�����̍X�V
	moveDir_ = charaObj_.GetRotation().dir_;
	float speed = mainAction_[act_]->GetSpeed();
	//�ړ��ʂ̍X�V
	movePow_ = VScale(moveDir_, speed);
}
const bool ActionController::IsCardLeftMoveable(void)
{
	//�J�[�hUI�̑I�����
	const CardUIBase::CARD_SELECT selectState = cardPresent_.GetCardUIState();

	return logic_.GetIsAct().isCardMoveLeft 
		&& selectState != CardUIBase::CARD_SELECT::RELOAD;
}
const bool ActionController::IsCardRightMoveable(void)
{
	//�J�[�hUI�̑I�����
	CardUIBase::CARD_SELECT selectState = cardPresent_.GetCardUIState();

	return logic_.GetIsAct().isCardMoveRight 
		&& selectState != CardUIBase::CARD_SELECT::RELOAD;
}

void ActionController::DesideAttackOne(void)
{
	//����Ƃ̋������擾
	const float dis = logic_.GetTargetDis();

	//����Ƃ̋��������ȉ��Ȃ�U������
	const float MIDDLE_DIS = 300.0f;

	//�����ɂ���čU���A�N�V�����J��
	if (dis >= MIDDLE_DIS)
	{
		ChangeAction(ACTION_TYPE::CARD_ATTACK_ONE_MIDDLE);
	}
	else
	{
		ChangeAction(ACTION_TYPE::CARD_ATTACK_ONE_SHORT);
	}
}

void ActionController::DesideEnemyCardAction(void)
{
	const float distance = logic_.GetTargetDis();

	//�����_���̐��l�擾
	int rand = GetRand(UtilityCommon::PERCENT_MAX);

	if (distance > ATK_DISTANCE)
	{
		//��������
		if (rand > STOMP_WEIGHT)
		{
			//�ʏ�U��
			ChangeAction(ACTION_TYPE::CARD_ATTACK_ENEMY_STOMP);
		}
		else if (rand < JUMP_WEIGHT)
		{
			//�W�����v
			ChangeAction(ACTION_TYPE::CARD_ATTACK_ENEMY_JUMP);
		}
	}
	else
	{
		//�ߋ�����
		if (rand > STOMP_WEIGHT)
		{
			//�ʏ�U��
			ChangeAction(ACTION_TYPE::CARD_ATTACK_ENEMY_STOMP);
		}
		else if (rand < JUMP_WEIGHT)
		{
			//�W�����v
			ChangeAction(ACTION_TYPE::CARD_ATTACK_ENEMY_JUMP);
		}	
	}
	logic_.SetIsActioning(true);
}

const bool ActionController::IsAttacable(void)
{
	std::vector<CardBase::CARD_TYPE>cardTypes = cardPresent_.GetHandCardType();
	int handCardTypeSize = static_cast<int>(cardPresent_.GetHandCardType().size());
	return handCardTypeSize == 1 && cardTypes[0] == CardBase::CARD_TYPE::ATTACK
		&&cardPresent_.GetCardUIState() != CardUIBase::CARD_SELECT::DISITION
		&& IsCardDecisionControl();
}

