#include "../pch.h"
#include "../pch.h"
#include "../Manager/Generic/SceneManager.h"
#include "../Manager/Generic/Camera.h"
#include "../../Base/CharacterBase.h"
#include "../../../Common/AnimationController.h"
#include "../ActionController.h"
#include "PlayerCardAttackOneShort.h"
#include "PlayerCardAttackTwo.h"

PlayerCardAttackTwo::PlayerCardAttackTwo(ActionController& _actCntl, CharacterBase& _charaObj, CardPresenter& _cardPresenter):
	PlayerCardAttackBase(_actCntl,_charaObj,_cardPresenter)
{
}

PlayerCardAttackTwo::~PlayerCardAttackTwo(void)
{
}

void PlayerCardAttackTwo::InitAttack(void)
{
	//�U��2�i�K�ڂ̃A�j���[�V�������Đ�
	anim_.PlayBlend(static_cast<int>(CharacterBase::ANIM_TYPE::ATTACK_2), animVar_);
	atkAnim_ = static_cast<int>(CharacterBase::ANIM_TYPE::ATTACK_2);
}

void PlayerCardAttackTwo::AttackUpdate(void)
{
	//�R���{���͎�t
	actionCntl_.ComboInput();

	//�U���̍X�V
	AttackMotion(atk_, Collider::TAG::NML_ATK, {});
}

void PlayerCardAttackTwo::LoadAnimVar(const ACTION_LOAD_DATA& _data)
{
	if (_data.name != "Attack_2")return;

	animVar_ = _data.animVariable;
	LoadAttackStatus(_data.jsonData, atk_);
}
