#include "../pch.h"
#include "../Manager/Generic/SceneManager.h"
#include "../Manager/Generic/UIManager.h"
#include "../Object/Common/AnimationController.h"
#include "../Action/ActionController.h"
#include "../Object/Character/Base/LogicBase.h"
#include "../Object/Character/Base/CharacterOnHitBase.h"
#include "../Object/Common/EffectController.h"
#include"../Object/Card/CardDeck.h"
#include"../Object/Card/CardUIBase.h"
#include "../Object/Stage.h"
#include "../../../Utility/Utility3D.h"
#include "../../Common/Geometry/Capsule.h"
#include "../../Common/Geometry/Sphere.h"
#include "../../Common/Geometry/Line.h"
#include "../Object/Character/Enemy/EnemyRock.h"
#include "../Object/ObjectBase.h"
#include "CharacterBase.h"

CharacterBase::CharacterBase(void) :
	movedPos_(Utility3D::VECTOR_ZERO),
	moveDiff_(Utility3D::VECTOR_ZERO),
	soundMng_(SoundManager::GetInstance()),
	isMoveable_(true),
	updatePhase_(UPDATE_PHASE::NONE),
	uiMng_(UIManager::GetInstance()),
	hitStopFrame_(HIT_STOP_FRAME),
	isEndClearDirect_(false)
{
	changeUpdate_ = {
		{UPDATE_PHASE::NONE,[this]() {ChangeUpdateNone(); }},
		{UPDATE_PHASE::NORMAL,[this]() {ChangeUpdateNormal(); }},
		{UPDATE_PHASE::DIRECTION, [this]() {ChangeUpdateDirection(); }},
		{UPDATE_PHASE::CLEAR_DIRECTION, [this]() {ChangeUpdateClearDirection(); }},
		{UPDATE_PHASE::OVER_DIRECTION, [this]() {ChangeUpdateOverDirection(); }},
		{UPDATE_PHASE::HIT_STOP,[this]() {ChangeUpdateHitStop(); } }
	};

	animStrTable_ = {
		{"Idle", ANIM_TYPE::IDLE},
		{"Run", ANIM_TYPE::RUN},
		{"React", ANIM_TYPE::REACT},
		{"Dodge", ANIM_TYPE::DODGE},
		{"Death", ANIM_TYPE::DEATH},
		{"React", ANIM_TYPE::REACT},
		{"Attack_1_Middle", ANIM_TYPE::ATTACK_1_MIDDLE},
		{"Attack_1_Short", ANIM_TYPE::ATTACK_1_SHORT},
		{"Attack_2", ANIM_TYPE::ATTACK_2},
		{"Attack_3", ANIM_TYPE::ATTACK_3},
		{"FireMagic", ANIM_TYPE::MAGIC_FIRE},
		{"Reload", ANIM_TYPE::CARD_RELOAD},
		{"StompAttack", ANIM_TYPE::STOMP_ATK},
		{"JumpAttack", ANIM_TYPE::JUMP_ATK},
		{"Rush_Atk", ANIM_TYPE::RUSH_ATK},
		{"Roar", ANIM_TYPE::ROAR_ATK},
	};
}

CharacterBase::~CharacterBase(void)
{
}

void CharacterBase::Update(void)
{
	phazeUpdate_();
}

void CharacterBase::MakeAttackCol(const Collider::TAG _charaTag, const Collider::TAG _attackTag, const VECTOR& _atkPos, const float& _radius)
{
	//�����蔻�肪���݂�����폜����
	if (IsAliveCollider(_charaTag, _attackTag))return;
	std::unique_ptr<Sphere>sphere = std::make_unique<Sphere>(_atkPos, _radius);

	MakeCollider(TAG_PRIORITY::ATK_SPHERE,{ _charaTag,_attackTag }, std::move(sphere),{Collider::TAG::STAGE});
}

void CharacterBase::UpdateAttackCol(const float _radius)
{
	//�����̔��a���U���̋��ɐݒ肷��
	Sphere& sphere=dynamic_cast<Sphere&>(collider_[TAG_PRIORITY::ATK_SPHERE]->GetGeometry());
	sphere.SetRadius(_radius);
}

void CharacterBase::DeleteAttackCol(const Collider::TAG& _charaTag, const Collider::TAG& _attackCol)
{
	if (!IsAliveCollider(_charaTag, _attackCol))return;
	DeleteCollider(TAG_PRIORITY::ATK_SPHERE);
}

void CharacterBase::UpdatePost(void)
{
	//�ړ�����W�̍X�V
	movedPos_ = VAdd(trans_.pos, action_->GetMovePow());

	//�ړ��ʃ��C���̍X�V
	VECTOR moveVec = VSub(movedPos_, trans_.pos);
	moveVec.y -= MOVE_LINE_Y_OFFSET;
	if (moveVec.x != 0.0f || moveVec.y != MOVE_LINE_Y_CHECK_VALUE || moveVec.z != 0.0f)
	{
		Line& moveLine = dynamic_cast<Line&>(collider_[TAG_PRIORITY::MOVE_LINE]->GetGeometry());
		moveLine.SetLocalPosPoint1(Utility3D::VECTOR_ZERO);
		moveLine.SetLocalPosPoint2(moveVec);
	}

	//�����蔻�������O�ɏ���������
	onHit_->InitHit();

	//�ړ�����
	MoveLimit(Stage::STAGE_POS, { Stage::STAGE_SIZE,0.0f, Stage::STAGE_SIZE });

	//�ړ��O�̍��W���i�[����
	moveDiff_ = trans_.pos;

	//�ړ�
	trans_.pos = movedPos_;
}

void CharacterBase::LoadStatus(void)
{
	//json���[�h
	nlohmann::json j = resMng_.Load(ResourceManager::SRC::CHARA_DATA).jsonData;

	std::string statusPath = "";

	characterType_ == CHARACTER_TYPE::PLAYER ? statusPath = PLAYER_STATUS_DATA
		: statusPath = ENEMY_STATUS_DATA;

	const auto& data = j[statusPath]["Status"];

	//�f�[�^���i�[
	if (data.contains("HP"))
	{
		maxStatus_.hp = data["HP"];
	}
	if (data.contains("SPD"))
	{
		maxStatus_.speed = data["SPD"];
	}

	//���݃X�e�[�^�X���ő�l�ɃZ�b�g
	status_ = maxStatus_;
}

void CharacterBase::MoveLimit(const VECTOR& _stagePos,const VECTOR& _stageSize)
{
	//�J�v�Z�����l�������X�e�[�W�̐����T�C�Y
	VECTOR subRadiusSize={_stageSize.x- capRadius_,0.0f,_stageSize.z- capRadius_};

	//�Z���^�[�T�C�Y
	VECTOR sizeHalf = VScale(subRadiusSize, 0.5f);

	//����
	VECTOR limit = VAdd(_stagePos, sizeHalf);

	//�ړ��x�N�g��
	VECTOR moveVec = Utility3D::GetMoveVec(trans_.pos, movedPos_);

	//�J�v�Z���֌W���l�������ړ����W
	VECTOR addPos = VScale(moveVec, capRadius_);

	//�������W
	VECTOR limitPos = VAdd(trans_.pos, addPos);

	//�����o���x�N�g��
	VECTOR pushVec = Utility3D::GetMoveVec(movedPos_, moveDiff_);
	pushVec.y = 0.0f;
	VECTOR pushPow = VScale(pushVec, action_->GetSpd());

	//�ړ�����
	if (limitPos.x >= limit.x)
	{
		movedPos_.x = limit.x + pushPow.x;
	}
	if (limitPos.x <= -limit.x)
	{
		movedPos_.x = -limit.x + pushPow.x;
	}
	if (limitPos.z >= limit.z)
	{
		movedPos_.z = limit.z + pushPow.z;
	}
	if (limitPos.z <= -limit.z)
	{
		movedPos_.z = -limit.z + pushPow.z;
	}
}

void CharacterBase::SetUsedCard(void)
{
	uiMng_.GetCardUI(characterType_).ChangeReactActionCard();
	deck_->EraseHandCard();
}

void CharacterBase::ChangeUpdatePhase(const UPDATE_PHASE _phase)
{
	if (updatePhase_ == _phase)return;
	updatePhase_ = _phase;
	changeUpdate_[updatePhase_]();
}

void CharacterBase::ChangeDirectToNormal(void)
{
	animationController_->PlayBlend(static_cast<int>(ANIM_TYPE::IDLE),idleAnim_);
	phazeUpdate_ = [this]() {UpdateNormal(); };
}

void CharacterBase::ChangeUpdateClearDirection(void)
{
	phazeUpdate_ = [this]() {UpdateClearDirection(); };
}

void CharacterBase::ChangeUpdateOverDirection(void)
{
	phazeUpdate_ = [this]() {UpdateOverDirection(); };
}

void CharacterBase::MoveDirFromInput(void)
{
}

void CharacterBase::Rotate(void)
{
	if (charaRot_.stepRotTime_ <= 0.0f)return;
	charaRot_.stepRotTime_ -= scnMng_.GetDeltaTime();

	// ��]�̋��ʕ��
	charaRot_.playerRotY_ = Quaternion::Slerp(
		charaRot_.playerRotY_, charaRot_.goalQuaRot_, (TIME_ROT - charaRot_.stepRotTime_) / TIME_ROT);
}

void CharacterBase::Damage(const int _dam)
{
	//�_���[�W���󂯂�O��UI��Ԃ��邽�߂�preHp���v�Z
	HP_DATA hpData = {};

	//���炷�O��hp������
	hpData.preHpPer = status_.hp / maxStatus_.hp;

	//�_���[�W��hp�����炷
	status_.hp -= _dam;

	//���炵�����HP������
	hpData.hpPer = status_.hp / maxStatus_.hp;

	//UI�}�l�[�W������X�V
	uiMng_.RefreshHpUI(characterType_, hpData);
}

const bool CharacterBase::GetIsDamage(void) const
{
	return action_->GetMainAction().GetIsDamage();
}

VECTOR CharacterBase::GetCharaCenterPos(void) const
{
	return collider_.at(ObjectBase::TAG_PRIORITY::BODY)->GetGeometry().GetCenter();
}

void CharacterBase::SetIsDamage(void)
{
	action_->GetMainAction().SetIsDamage();
}

void CharacterBase::SetFlinchCnt(const float _flichCnt)
{
	action_->SetFlinchCnt(_flichCnt);
}

const bool CharacterBase::GetIsJumpAtk(void) const
{
	return action_->GetMainAction().IsJumpAtk();
}

const ActionBase& CharacterBase::GetMainAction(void) const
{
	return action_->GetMainAction();
}

const CharacterOnHitBase::HIT_POINT& CharacterBase::GetHitPoint(void) const
{
	return onHit_->GetHitPoint();
}

void CharacterBase::SetLogicTargetCharacter(std::shared_ptr<CharacterBase> _targetChara)
{
	logic_->SetTargetCharacter(_targetChara);
}

void CharacterBase::AddEnemyRock(const int _num, VECTOR& _atkPos)
{
	for (int i = 0; i < _num; i++)
	{
		std::unique_ptr<EnemyRock> rock = std::make_unique<EnemyRock>(i, _atkPos);
		rock_.emplace_back(std::move(rock));
	}
}

void CharacterBase::LoadEnemyRock(void)
{
	if (rock_.empty())return;
	for (auto& rock : rock_)
	{
		rock->Load();
	}
}

void CharacterBase::DeleteEnemyRockCol(void)
{
	if (rock_.empty())return;
	for (auto& rock : rock_)
	{
		rock->DeleteRockCollider();
	}
}

void CharacterBase::SetIsAliveEnemyRock(const bool _isAlive)
{
	if (rock_.empty())return;
	for (auto& rock : rock_)
	{
		rock->SetIsAlive(_isAlive);
		if (_isAlive)
		{
			rock->Init();
		}
	}
}

void CharacterBase::EnemyRockUpdate(void)
{
	if (rock_.empty())return;
	for (auto& rock : rock_)
	{
		rock->Update();
	}
}
const bool CharacterBase::GetIsHitTarget(void) const
{
	return onHit_->GetIsHitTarget();
}

void CharacterBase::LoadAddAnimation(OnActionDataLoaded callBack)
{
	//�f�[�^�ǂݍ���
	nlohmann::json j = resMng_.Load(ResourceManager::SRC::ACTION_DATA).jsonData;

	//�L�����N�^�[���ƂŃp�X��ς���
	std::string statusPath = "";
	characterType_ == CHARACTER_TYPE::PLAYER ? statusPath = PLAYER_STATUS_DATA
		: statusPath = ENEMY_STATUS_DATA;

	const auto& actionData = j[statusPath];

	// �A�N�V�������Ƃ̎g�p�A�j���[�V������ǂݎ����
	// �A�j���[�V�����R���g���[���[�ɒǉ�����
	for (const auto& [name,data] : actionData.items())
	{
		ACTION_LOAD_DATA actionLoadData = {name, {}, data};

		//animation�̃f�[�^������Ίi�[����
		if (data.contains("animation"))
		{
			//�A�j���[�V�����f�[�^�̎擾
			const auto& animData = data["animation"];

			////Json�̃��X�g���Ɠo�^��񂪈�v���Ă��邩�𒲂ׂ�
			////�g�p�A�j���[�V�����̎擾
			std::string useAnim = animData.value("useAnim", "");
			auto nameIt = animStrTable_.find(name);
			if (nameIt == animStrTable_.end())continue;

			//�g�p���郊�\�[�X���擾
			ResourceManager::SRC useSrc = resMng_.GetSrcFromString(useAnim);

			//�Đ�����Ƃ��̃p�����[�^���i�[
			AnimationController::ANIMATION_VARIABLE animVariable = {};

			if (useSrc != ResourceManager::SRC::NONE)
			{
				//�A�j���[�V�����ɒǉ�
				animationController_->Add(static_cast<int>(nameIt->second), resMng_.LoadModelDuplicate(useSrc));
			}

			//�A�j���[�V�������x�̎擾
			if (animData.contains("animSpeed"))
			{
				animVariable.speed = animData.value("animSpeed", 0.0f);
			}

			//�f�^�b�`�X�s�[�h�̎擾
			if (animData.contains("detachSpeed"))
			{
				animVariable.detachSpeed = animData.value("detachSpeed", 0.0f);
			}

			//���[�v�t���O�̊i�[
			if (animData.contains("isLoop"))
			{
				animVariable.isLoop = animData.value("isLoop", false);
			}

			//�X�^�[�g�X�e�b�v�̎擾
			if (animData.contains("startStep"))
			{
				animVariable.step = animData.value("startStep", 0.0f);
			}

			//�I���X�e�b�v�̎擾
			if (animData.contains("endStep"))
			{
				animVariable.totalTime = animData.value("endStep", 0.0f);
			}

			actionLoadData.animVariable = animVariable;
		}

		if(callBack)
		{
			callBack(actionLoadData);
		}

	}
}

void CharacterBase::UpdateNone(void)
{
	//�������Ȃ�
}

void CharacterBase::UpdateHitStop(void)
{
	if (--hitStopFrame_ > 0)return;
	hitStopFrame_ = HIT_STOP_FRAME;
	ChangeUpdatePhase(UPDATE_PHASE::NORMAL);
}

void CharacterBase::ChangeUpdateNone(void)
{
	phazeUpdate_ = [this]() {UpdateNone(); };
}

void CharacterBase::ChangeUpdateNormal(void)
{
	phazeUpdate_ = [this]() {UpdateNormal(); };
}

void CharacterBase::ChangeUpdateDirection(void)
{
	phazeUpdate_ = [this]() { UpdateDirection(); };
}

void CharacterBase::ChangeUpdateHitStop(void)
{
	phazeUpdate_ = [this]() { UpdateHitStop(); };
}
